/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Patient, Appointment, TreatmentItem, Odontogram } from './types';

// Tooth list with names (Universal Numbering System 1 - 32)
export const UNIVERSAL_TEETH = [
  // Upper Right Quadrant
  { num: 1, name: "Third Molar (Wisdom Tooth)", arch: "Upper", quad: "Right" },
  { num: 2, name: "Second Molar", arch: "Upper", quad: "Right" },
  { num: 3, name: "First Molar", arch: "Upper", quad: "Right" },
  { num: 4, name: "Second Premolar (Bicuspid)", arch: "Upper", quad: "Right" },
  { num: 5, name: "First Premolar (Bicuspid)", arch: "Upper", quad: "Right" },
  { num: 6, name: "Cuspid (Canine/Eye Tooth)", arch: "Upper", quad: "Right" },
  { num: 7, name: "Lateral Incisor", arch: "Upper", quad: "Right" },
  { num: 8, name: "Central Incisor", arch: "Upper", quad: "Right" },
  // Upper Left Quadrant
  { num: 9, name: "Central Incisor", arch: "Upper", quad: "Left" },
  { num: 10, name: "Lateral Incisor", arch: "Upper", quad: "Left" },
  { num: 11, name: "Cuspid (Canine/Eye Tooth)", arch: "Upper", quad: "Left" },
  { num: 12, name: "First Premolar (Bicuspid)", arch: "Upper", quad: "Left" },
  { num: 13, name: "Second Premolar (Bicuspid)", arch: "Upper", quad: "Left" },
  { num: 14, name: "First Molar", arch: "Upper", quad: "Left" },
  { num: 15, name: "Second Molar", arch: "Upper", quad: "Left" },
  { num: 16, name: "Third Molar (Wisdom Tooth)", arch: "Upper", quad: "Left" },
  // Lower Left Quadrant
  { num: 17, name: "Third Molar (Wisdom Tooth)", arch: "Lower", quad: "Left" },
  { num: 18, name: "Second Molar", arch: "Lower", quad: "Left" },
  { num: 19, name: "First Molar", arch: "Lower", quad: "Left" },
  { num: 20, name: "Second Premolar (Bicuspid)", arch: "Lower", quad: "Left" },
  { num: 21, name: "First Premolar (Bicuspid)", arch: "Lower", quad: "Left" },
  { num: 22, name: "Cuspid (Canine/Eye Tooth)", arch: "Lower", quad: "Left" },
  { num: 23, name: "Lateral Incisor", arch: "Lower", quad: "Left" },
  { num: 24, name: "Central Incisor", arch: "Lower", quad: "Left" },
  // Lower Right Quadrant
  { num: 25, name: "Central Incisor", arch: "Lower", quad: "Right" },
  { num: 26, name: "Lateral Incisor", arch: "Lower", quad: "Right" },
  { num: 27, name: "Cuspid (Canine/Eye Tooth)", arch: "Lower", quad: "Right" },
  { num: 28, name: "First Premolar (Bicuspid)", arch: "Lower", quad: "Right" },
  { num: 29, name: "Second Premolar (Bicuspid)", arch: "Lower", quad: "Right" },
  { num: 30, name: "First Molar", arch: "Lower", quad: "Right" },
  { num: 31, name: "Second Molar", arch: "Lower", quad: "Right" },
  { num: 32, name: "Third Molar (Wisdom Tooth)", arch: "Lower", quad: "Right" },
];

export const PROCEDURE_TEMPLATES = [
  { code: "D0120", name: "Periodic Oral Evaluation", category: "Diagnostic", cost: 350 },
  { code: "D0150", name: "Comprehensive Oral Evaluation", category: "Diagnostic", cost: 600 },
  { code: "D0210", name: "Intraoral Radiographs - Full Series", category: "Diagnostic", cost: 800 },
  { code: "D1110", name: "Prophylaxis (Dental Cleaning) - Adult", category: "Preventive", cost: 500 },
  { code: "D1208", name: "Topical Application of Fluoride", category: "Preventive", cost: 250 },
  { code: "D2331", name: "Resin Composite Filling - 2 Surfaces", category: "Restorative", cost: 1200 },
  { code: "D2393", name: "Resin Composite Filling - 3 Surfaces, Posterior", category: "Restorative", cost: 1600 },
  { code: "D2750", name: "Porcelain Crown Fused to High Noble Metal", category: "Restorative", cost: 6000 },
  { code: "D3330", name: "Endodontic Therapy (Root Canal) - Molar", category: "Endodontic", cost: 4800 },
  { code: "D4341", name: "Periodontal Scaling and Root Planing - Quadrant", category: "Periodontal", cost: 1400 },
  { code: "D5110", name: "Complete Denture - Maxillary (Upper)", category: "Prosthodontic", cost: 9000 },
  { code: "D6010", name: "Surgical Placement of Implant Body", category: "Prosthodontic", cost: 12000 },
  { code: "D7140", name: "Extraction, Erupted Tooth or Exposed Root", category: "Oral Surgery", cost: 1000 },
  { code: "D7210", name: "Surgical Extraction of Erupted Tooth", category: "Oral Surgery", cost: 1800 },
  { code: "D8080", name: "Comprehensive Orthodontic Treatment", category: "Orthodontic", cost: 25000 },
];

// Helper to generate empty odontogram
export function createEmptyOdontogram(): Odontogram {
  const o: Odontogram = {};
  for (let i = 1; i <= 32; i++) {
    o[i] = {
      surfaces: {
        top: 'healthy',
        bottom: 'healthy',
        left: 'healthy',
        right: 'healthy',
        center: 'healthy',
        all: 'healthy',
      },
      notes: '',
    };
  }
  return o;
}

// Generate some sample patient records
export const getSamplePatients = (): Patient[] => {
  // Patient 1: Johnathan Doe
  const p1Odontogram = createEmptyOdontogram();
  // Caries on tooth #3 center surface, and #14 left (mesial) surface
  p1Odontogram[3].surfaces.center = 'caries';
  p1Odontogram[3].notes = 'Moderate decay in occlusal pit.';
  p1Odontogram[14].surfaces.left = 'caries';
  p1Odontogram[14].notes = 'Interproximal decay detected on mesial aspect.';
  // Tooth #1 is missing (wisdom tooth extracted)
  p1Odontogram[1].surfaces.all = 'missing';
  // Tooth #19 has a crown
  p1Odontogram[19].surfaces.all = 'crown';
  p1Odontogram[19].notes = 'PFM Crown placed in 2024. Margins clean.';
  // Tooth #30 has root canal
  p1Odontogram[30].surfaces.all = 'root_canal';
  p1Odontogram[30].surfaces.center = 'filled';
  p1Odontogram[30].notes = 'Root canal completed. Composite access restoration intact.';

  // Patient 2: Sarah Lin
  const p2Odontogram = createEmptyOdontogram();
  // Beautiful healthy teeth, just tooth #16 wisdom tooth missing
  p2Odontogram[16].surfaces.all = 'missing';
  p2Odontogram[17].surfaces.all = 'missing';
  p2Odontogram[32].surfaces.all = 'missing';
  p2Odontogram[4].surfaces.center = 'filled'; // small composite filling

  // Patient 3: Marcus Henderson (Elderly patient with bridge and implant)
  const p3Odontogram = createEmptyOdontogram();
  p3Odontogram[1].surfaces.all = 'missing';
  p3Odontogram[2].surfaces.all = 'missing';
  p3Odontogram[16].surfaces.all = 'missing';
  p3Odontogram[17].surfaces.all = 'missing';
  // Bridge on #11, #12, #13
  p3Odontogram[11].surfaces.all = 'bridge';
  p3Odontogram[12].surfaces.all = 'bridge'; // pontic
  p3Odontogram[13].surfaces.all = 'bridge';
  // Implant on tooth #8
  p3Odontogram[8].surfaces.all = 'implant';
  p3Odontogram[8].notes = 'Single-tooth titanium implant placed in 2023. Bone levels excellent.';

  return [
    {
       id: "PAT-001",
      name: "Kofi Mensah",
      dob: "1984-05-15",
      gender: "Male",
      phone: "+233 24 123 4567",
      email: "kofi.mensah@email.gh",
      address: "No. 45 Anumsa Street, East Legon, Accra, Ghana",
      bloodType: "A+",
      allergies: ["Penicillin", "Sulfa Drugs"],
      chronicConditions: ["Hypertension"],
      emergencyContact: {
        name: "Clara Mensah",
        relationship: "Spouse",
        phone: "+233 24 123 4568"
      },
      odontogram: p1Odontogram,
      treatments: [
        {
          id: "TX-101",
          code: "D0150",
          name: "Comprehensive Oral Evaluation",
          category: "Diagnostic",
          cost: 600,
          notes: "Initial diagnostic workup and screening.",
          status: "completed",
          date: "2026-05-10"
        },
        {
          id: "TX-102",
          code: "D1110",
          name: "Prophylaxis (Dental Cleaning) - Adult",
          category: "Preventive",
          cost: 500,
          notes: "Routine prophylaxis and calculus scaling.",
          status: "completed",
          date: "2026-05-10"
        },
        {
          id: "TX-103",
          code: "D2331",
          name: "Resin Composite Filling - 2 Surfaces",
          category: "Restorative",
          cost: 1200,
          notes: "Planned for caries on Tooth #14 mesial.",
          status: "planned",
          date: "2026-06-29"
        },
        {
          id: "TX-104",
          code: "D2393",
          name: "Resin Composite Filling - 3 Surfaces, Posterior",
          category: "Restorative",
          cost: 1600,
          notes: "Planned for occlusal caries on Tooth #3.",
          status: "planned",
          date: "2026-06-29"
        },
      ],
      xrays: [
        {
          id: "XR-001",
          name: "Panoramic Radiograph (OPG)",
          date: "2026-05-10",
          imageUrl: "https://images.unsplash.com/photo-1579684389782-64d84b5e9053?q=80&w=800&auto=format&fit=crop", // abstract/radiograph representation
          notes: "General panoramic bone levels adequate, mild alveolar ridge reduction in lower posterior.",
          annotations: [
            { id: "A-1", x: 25, y: 40, label: "Missing tooth #1", details: "Completely missing wisdom tooth slot" },
            { id: "A-2", x: 68, y: 45, label: "Caries #14", details: "Interproximal radiolucency on mesial wall" },
            { id: "A-3", x: 35, y: 55, label: "Existing Crown #19", details: "Radiopaque crown margins look flush and well-sealed" }
          ]
        },
        {
          id: "XR-002",
          name: "Bite-wing X-Ray Right",
          date: "2026-05-10",
          imageUrl: "https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?q=80&w=800&auto=format&fit=crop",
          notes: "Localized bite-wing view focusing on teeth #3 - #5.",
          annotations: [
            { id: "A-4", x: 45, y: 35, label: "Occlusal Caries #3", details: "Incipient radiolucency into dentino-enamel junction (DEJ)" }
          ]
        }
      ],
      invoices: [
        {
          id: "INV-001",
          patientId: "PAT-001",
          date: "2026-05-10",
          items: [
            { name: "Comprehensive Oral Evaluation (D0150)", cost: 600 },
            { name: "Prophylaxis (Dental Cleaning) (D1110)", cost: 500 }
          ],
          discount: 0,
          tax: 5,
          total: 1155,
          insurancePaid: 800,
          amountPaid: 355,
          status: "paid"
        },
        {
          id: "INV-002",
          patientId: "PAT-001",
          date: "2026-06-29",
          items: [
            { name: "Resin Composite Filling (D2331) - Est.", cost: 1200 },
            { name: "Resin Composite Filling (D2393) - Est.", cost: 1600 }
          ],
          discount: 10, // 10% discount
          tax: 5,
          total: 2646,
          insurancePaid: 0,
          amountPaid: 0,
          status: "unpaid"
        }
      ],
      balance: 2646
    },
    {
      id: "PAT-002",
      name: "Ama Serwaa",
      dob: "1997-11-23",
      gender: "Female",
      phone: "+233 20 876 5432",
      email: "ama.serwaa@email.gh",
      address: "Plot 12, Ring Road Central, Osu, Accra, Ghana",
      bloodType: "O-",
      allergies: ["Aspirin"],
      chronicConditions: ["Asthma"],
      emergencyContact: {
        name: "Yaw Serwaa",
        relationship: "Brother",
        phone: "+233 20 876 5433"
      },
      odontogram: p2Odontogram,
      treatments: [
        {
          id: "TX-201",
          code: "D0120",
          name: "Periodic Oral Evaluation",
          category: "Diagnostic",
          cost: 350,
          notes: "Routine checkup, very clean dental health.",
          status: "completed",
          date: "2026-06-15"
        },
        {
          id: "TX-202",
          code: "D1110",
          name: "Prophylaxis (Dental Cleaning) - Adult",
          category: "Preventive",
          cost: 500,
          notes: "General scaling and polishing.",
          status: "completed",
          date: "2026-06-15"
        }
      ],
      xrays: [],
      invoices: [
        {
          id: "INV-201",
          patientId: "PAT-002",
          date: "2026-06-15",
          items: [
            { name: "Periodic Oral Evaluation (D0120)", cost: 350 },
            { name: "Prophylaxis (Dental Cleaning) (D1110)", cost: 500 }
          ],
          discount: 0,
          tax: 5,
          total: 892.5,
          insurancePaid: 600,
          amountPaid: 292.5,
          status: "paid"
        }
      ],
      balance: 0
    },
    {
      id: "PAT-003",
      name: "Nii Armah Tackie",
      dob: "1968-03-09",
      gender: "Male",
      phone: "+233 55 332 1098",
      email: "niinarmah.tackie@email.gh",
      address: "Block B, Ahodwo Residential Area, Kumasi, Ghana",
      bloodType: "B+",
      allergies: [],
      chronicConditions: ["Type 2 Diabetes", "Mild Arthritis"],
      emergencyContact: {
        name: "Lillian Tackie",
        relationship: "Spouse",
        phone: "+233 55 332 1099"
      },
      odontogram: p3Odontogram,
      treatments: [
        {
          id: "TX-301",
          code: "D0150",
          name: "Comprehensive Oral Evaluation",
          category: "Diagnostic",
          cost: 600,
          notes: "Senior patient periodic evaluation.",
          status: "completed",
          date: "2026-04-12"
        },
        {
          id: "TX-302",
          code: "D6010",
          name: "Surgical Placement of Implant Body",
          category: "Prosthodontic",
          cost: 12000,
          notes: "Implant placed in Tooth #8 position.",
          status: "completed",
          date: "2026-04-12"
        },
        {
          id: "TX-303",
          code: "D2750",
          name: "Porcelain Crown Fused to Metal",
          category: "Restorative",
          cost: 6000,
          notes: "Abutment and Crown for Tooth #8 implant.",
          status: "in_progress",
          date: "2026-07-05"
        }
      ],
      xrays: [
        {
          id: "XR-301",
          name: "Implant Position Radiograph #8",
          date: "2026-04-12",
          imageUrl: "https://images.unsplash.com/photo-1559757175-5700dde675bc?q=80&w=800&auto=format&fit=crop",
          notes: "Post-surgical radiograph showing excellent implant angle and osseointegration starting.",
          annotations: [
            { id: "A-30", x: 49, y: 38, label: "Titanium Implant Body #8", details: "Well aligned in alveolar socket, secure primary stability" }
          ]
        }
      ],
      invoices: [
        {
          id: "INV-301",
          patientId: "PAT-003",
          date: "2026-04-12",
          items: [
            { name: "Comprehensive Evaluation (D0150)", cost: 600 },
            { name: "Surgical Placement of Implant (D6010)", cost: 12000 }
          ],
          discount: 1000, // VIP discount
          tax: 5,
          total: 12180,
          insurancePaid: 8000,
          amountPaid: 4180,
          status: "paid"
        },
        {
          id: "INV-302",
          patientId: "PAT-003",
          date: "2026-06-25",
          items: [
            { name: "Porcelain Crown Abutment #8 (D2750)", cost: 6000 }
          ],
          discount: 0,
          tax: 5,
          total: 6300,
          insurancePaid: 4000,
          amountPaid: 0,
          status: "partial"
        }
      ],
      balance: 2300
    }
  ];
};

// Initial Appointment List
export const getSampleAppointments = (): Appointment[] => {
  return [
    {
      id: "APT-001",
      patientId: "PAT-001",
      patientName: "Kofi Mensah",
      dentistName: "Dr. Bezaleel Mawutorwu Mawugbe",
      dateTime: "2026-06-28T09:00:00", // Today at 9 AM
      duration: 45,
      reason: "Resin composite filling on teeth #3 and #14",
      notes: "Anesthetize upper left and upper right quadrants.",
      status: "scheduled"
    },
    {
      id: "APT-002",
      patientId: "PAT-002",
      patientName: "Ama Serwaa",
      dentistName: "Dr. Bezaleel Mawutorwu Mawugbe",
      dateTime: "2026-06-28T11:15:00", // Today at 11:15 AM
      duration: 30,
      reason: "Routine Follow-up & Fluoride",
      notes: "Check gums on lower molars.",
      status: "scheduled"
    },
    {
      id: "APT-003",
      patientId: "PAT-003",
      patientName: "Nii Armah Tackie",
      dentistName: "Dr. Bezaleel Mawutorwu Mawugbe",
      dateTime: "2026-06-29T14:00:00", // Tomorrow at 2:00 PM
      duration: 60,
      reason: "Porcelain crown abutment fitting #8",
      notes: "Verify crown margins and shade matching.",
      status: "scheduled"
    },
    {
      id: "APT-004",
      patientId: "PAT-001",
      patientName: "Kofi Mensah",
      dentistName: "Dr. Bezaleel Mawutorwu Mawugbe",
      dateTime: "2026-05-10T10:00:00", // Past
      duration: 60,
      reason: "Comprehensive Eval & Prophylaxis",
      notes: "Completed successfully.",
      status: "completed"
    },
    {
      id: "APT-005",
      patientId: "PAT-002",
      patientName: "Ama Serwaa",
      dentistName: "Dr. Bezaleel Mawutorwu Mawugbe",
      dateTime: "2026-06-15T09:30:00", // Past
      duration: 45,
      reason: "Routine cleaning & checkup",
      notes: "Very clean oral health.",
      status: "completed"
    }
  ];
};
