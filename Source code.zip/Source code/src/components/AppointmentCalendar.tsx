/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Appointment, Patient } from '../types';
import { Calendar, Clock, Plus, Trash2, CheckCircle2, XCircle, AlertCircle, RefreshCw } from 'lucide-react';

interface AppointmentCalendarProps {
  appointments: Appointment[];
  patients: Patient[];
  onAddAppointment: (newApt: Appointment) => void;
  onUpdateAppointmentStatus: (aptId: string, status: Appointment['status']) => void;
  onDeleteAppointment: (aptId: string) => void;
}

const HOURS = [
  "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"
];

export default function AppointmentCalendar({
  appointments,
  patients,
  onAddAppointment,
  onUpdateAppointmentStatus,
  onDeleteAppointment
}: AppointmentCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<string>("2026-06-28"); // Default matching local simulated date
  const [showAddForm, setShowAddForm] = useState(false);

  // Form State
  const [patientId, setPatientId] = useState('');
  const [dentistName, setDentistName] = useState('Dr. Bezaleel Mawutorwu Mawugbe');
  const [selectedHour, setSelectedHour] = useState('09:00');
  const [duration, setDuration] = useState<number>(45);
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');

  const handleCreateAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientId || !reason) return;

    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    const dateTimeStr = `${selectedDate}T${selectedHour}:00`;

    const newApt: Appointment = {
      id: `APT-0${appointments.length + 11}`,
      patientId,
      patientName: patient.name,
      dentistName,
      dateTime: dateTimeStr,
      duration,
      reason,
      notes,
      status: 'scheduled'
    };

    onAddAppointment(newApt);
    
    // Reset Form
    setPatientId('');
    setReason('');
    setNotes('');
    setShowAddForm(false);
  };

  // Filter appointments for selected date
  const dailyAppointments = appointments.filter(apt => apt.dateTime.startsWith(selectedDate));

  const getStatusStyle = (status: Appointment['status']) => {
    switch (status) {
      case 'completed': return 'bg-emerald-50 border-emerald-100 text-emerald-700';
      case 'cancelled': return 'bg-red-50 border-red-100 text-red-700';
      case 'no_show': return 'bg-amber-50 border-amber-100 text-amber-700';
      default: return 'bg-red-50 border-red-100 text-red-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Date Navigation & Actions bar */}
      <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-red-50 text-red-600 rounded-xl">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">Clinical Calendar Scheduler</h3>
            <p className="text-xs text-slate-500">Book clinical slots, assign practitioners, and manage checking-in patient states.</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          {/* Quick Date Inputs */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 shrink-0">
            <span className="text-xs font-bold text-slate-400">Date:</span>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent border-none text-slate-700 font-bold text-xs focus:outline-none focus:ring-0 cursor-pointer"
            />
          </div>

          <button
            onClick={() => setShowAddForm(true)}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 py-2.5 px-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Book Chair Appointment
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Chair Timeslots Grid */}
        <div className="xl:col-span-8 bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h4 className="text-sm font-bold text-slate-900">Chair Scheduling Grid for {selectedDate}</h4>
            <div className="text-[10px] text-slate-400 font-semibold flex items-center gap-1">
              <span>Simulated Date</span>
            </div>
          </div>

          <div className="space-y-4">
            {HOURS.map(hour => {
              // Find appointments matching this hour slot
              const slotAppointments = dailyAppointments.filter(apt => {
                const aptHour = apt.dateTime.split('T')[1].substring(0, 5);
                return aptHour === hour;
              });

              return (
                <div key={hour} className="flex gap-4 items-start group">
                  {/* Time label */}
                  <div className="w-16 py-1 text-xs font-bold text-slate-400 select-none text-right font-mono mt-1 shrink-0">
                    {hour}
                  </div>

                  {/* Timeslot card container */}
                  <div className="flex-1 min-h-[70px] border-l-2 border-slate-200 group-hover:border-red-500 pl-4 py-1 flex flex-col gap-2 transition-colors">
                    {slotAppointments.length > 0 ? (
                      slotAppointments.map(apt => (
                        <div 
                          key={apt.id}
                          className={`border rounded-2xl p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 transition-all hover:shadow-sm ${getStatusStyle(apt.status)}`}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-sm">{apt.patientName}</span>
                              <span className="text-[10px] font-bold px-1.5 py-0.5 bg-black/5 rounded-md capitalize">{apt.status}</span>
                            </div>
                            <div className="text-xs font-semibold mt-1 opacity-90 flex flex-wrap items-center gap-1">
                              <span>Reason: {apt.reason}</span>
                              <span>•</span>
                              <span className="font-mono text-[10px] opacity-75">{apt.duration} min duration</span>
                            </div>
                            {apt.notes && (
                              <p className="text-[10px] mt-2 italic opacity-75 border-t border-black/5 pt-1 max-w-lg leading-relaxed">
                                Clinical Notes: {apt.notes}
                              </p>
                            )}
                          </div>

                          {/* Controls */}
                          <div className="flex items-center gap-1 bg-black/5 p-1 rounded-xl w-fit self-end md:self-auto">
                            {apt.status === 'scheduled' && (
                              <>
                                <button
                                  onClick={() => onUpdateAppointmentStatus(apt.id, 'completed')}
                                  className="p-1.5 hover:bg-emerald-500 hover:text-white rounded-lg transition-colors text-slate-500"
                                  title="Check-in & Complete"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => onUpdateAppointmentStatus(apt.id, 'cancelled')}
                                  className="p-1.5 hover:bg-red-500 hover:text-white rounded-lg transition-colors text-slate-500"
                                  title="Cancel Appointment"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => onUpdateAppointmentStatus(apt.id, 'no_show')}
                                  className="p-1.5 hover:bg-amber-500 hover:text-white rounded-lg transition-colors text-slate-500"
                                  title="Mark No Show"
                                >
                                  <AlertCircle className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                            <button
                              onClick={() => {
                                if (confirm("Remove this appointment slot?")) {
                                  onDeleteAppointment(apt.id);
                                }
                              }}
                              className="p-1.5 hover:bg-slate-700 hover:text-white rounded-lg transition-colors text-slate-500"
                              title="Delete Slot"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <button
                        onClick={() => {
                          setSelectedHour(hour);
                          setShowAddForm(true);
                        }}
                        className="w-full text-left py-2 px-3 border border-dashed border-slate-200 hover:border-red-500/50 bg-slate-50/40 hover:bg-red-50/10 rounded-xl transition-all group/btn flex items-center justify-between text-slate-400 hover:text-red-600 cursor-pointer"
                      >
                        <span className="text-[11px] font-semibold flex items-center gap-1.5">
                          <Plus className="w-3.5 h-3.5 stroke-[2.5] text-slate-300 group-hover/btn:text-red-500 group-hover/btn:scale-110 transition-transform" />
                          Chair Slot Vacant
                        </span>
                        <span className="text-[9px] uppercase font-bold tracking-wider text-slate-300 group-hover/btn:text-red-400 font-mono">
                          Quick Book {hour}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Dynamic Summary Panel */}
        <div className="xl:col-span-4 space-y-4">
          <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Scheduling Summary</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 border border-slate-100 p-3.5 rounded-xl text-center">
                <div className="text-2xl font-black text-slate-800">{dailyAppointments.length}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-1">Daily Bookings</div>
              </div>
              <div className="bg-slate-50 border border-slate-100 p-3.5 rounded-xl text-center">
                <div className="text-2xl font-black text-emerald-600">
                  {dailyAppointments.filter(a => a.status === 'completed').length}
                </div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-1">Completed</div>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4 mt-4 space-y-2 text-xs text-slate-500 leading-relaxed">
              <div className="font-bold text-slate-700">Practitioner Guidelines:</div>
              <p>1. Keep clinical sessions padded with 15-minute cleaning turnovers.</p>
              <p>2. Pre-medicate hypertensive patients or penicillin allergy cases at least 1 hour prior.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Book Chair Appointment Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white border border-slate-100 rounded-2xl shadow-xl w-full max-w-lg p-6 relative">
            <button
              onClick={() => setShowAddForm(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-xl font-bold p-1 hover:bg-slate-50 rounded-lg"
            >
              &times;
            </button>

            <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3 mb-4">Book Chair Appointment Slot</h3>

            <form onSubmit={handleCreateAppointment} className="space-y-4">
              {/* Patient */}
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Select Patient *</label>
                <select
                  required
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 bg-white"
                >
                  <option value="">-- Choose Registered Patient --</option>
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.id})</option>
                  ))}
                </select>
              </div>

              {/* Dentist & Hour */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-500 block mb-1">Chair / Dentist *</label>
                  <select
                    value={dentistName}
                    onChange={(e) => setDentistName(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 bg-white"
                  >
                    <option value="Dr. Bezaleel Mawutorwu Mawugbe">Dr. Bezaleel Mawutorwu Mawugbe</option>
                    <option value="Dr. Kofi Mensah">Dr. Kofi Mensah</option>
                    <option value="Dr. Ama Osei">Dr. Ama Osei</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-500 block mb-1">Time Slot *</label>
                  <select
                    value={selectedHour}
                    onChange={(e) => setSelectedHour(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 bg-white font-mono"
                  >
                    {HOURS.map(h => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Duration */}
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Session Duration (minutes)</label>
                <select
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 bg-white"
                >
                  <option value={15}>15 mins (quick checkout/fluoride)</option>
                  <option value={30}>30 mins (checkup / scaling)</option>
                  <option value={45}>45 mins (standard cleaning/filling)</option>
                  <option value={60}>60 mins (root canal / minor surgery)</option>
                  <option value={90}>90 mins (complex implant placement)</option>
                </select>
              </div>

              {/* Reason */}
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Reason for Visit *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tooth scaling or implant placement abutment fitting"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Clinical Pre-visit Notes (optional)</label>
                <textarea
                  rows={3}
                  placeholder="Note allergies, medication requirements, or checkup focus points..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 resize-none"
                />
              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="py-2 px-3 border border-slate-200 hover:bg-slate-50 text-slate-500 font-bold text-xs rounded-lg transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2 px-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  Book Slot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
