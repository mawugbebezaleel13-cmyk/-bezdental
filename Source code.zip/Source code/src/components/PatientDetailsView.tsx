/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Patient, Odontogram, TreatmentItem, XRayFile, XRayAnnotation, Invoice } from '../types';
import DentalChart from './DentalChart';
import TreatmentPlanner from './TreatmentPlanner';
import XRayViewer from './XRayViewer';
import { 
  ArrowLeft, 
  User, 
  AlertTriangle, 
  Activity, 
  ShieldAlert, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar,
  Layers,
  FileText,
  Image as ImageIcon,
  HeartPulse
} from 'lucide-react';

interface PatientDetailsViewProps {
  patient: Patient;
  onBackToList: () => void;
  onUpdatePatientData: (updatedPatient: Patient) => void;
}

type ActiveSubTab = 'chart' | 'treatment' | 'imaging';

export default function PatientDetailsView({ 
  patient, 
  onBackToList, 
  onUpdatePatientData 
}: PatientDetailsViewProps) {
  const [activeTab, setActiveTab] = useState<ActiveSubTab>('chart');

  // Handle Odontogram Changes
  const handleChartChange = (updatedOdontogram: Odontogram) => {
    // Recalculate patient balance if needed or just save
    const updatedPatient: Patient = {
      ...patient,
      odontogram: updatedOdontogram
    };
    onUpdatePatientData(updatedPatient);
  };

  // Add Treatment item
  const handleAddTreatment = (patientId: string, item: TreatmentItem) => {
    const updatedTreatments = [...patient.treatments, item];
    const updatedPatient: Patient = {
      ...patient,
      treatments: updatedTreatments
    };
    onUpdatePatientData(updatedPatient);
  };

  // Update Treatment status
  const handleUpdateTreatmentStatus = (patientId: string, txId: string, status: TreatmentItem['status']) => {
    const updatedTreatments = patient.treatments.map(t => {
      if (t.id === txId) {
        return { ...t, status };
      }
      return t;
    });

    const updatedPatient: Patient = {
      ...patient,
      treatments: updatedTreatments
    };
    onUpdatePatientData(updatedPatient);
  };

  // Delete Treatment item
  const handleDeleteTreatment = (patientId: string, txId: string) => {
    const updatedTreatments = patient.treatments.filter(t => t.id !== txId);
    const updatedPatient: Patient = {
      ...patient,
      treatments: updatedTreatments
    };
    onUpdatePatientData(updatedPatient);
  };

  // Compile Invoice
  const handleAddInvoice = (patientId: string, invoice: Invoice) => {
    const updatedInvoices = [...patient.invoices, invoice];
    
    // Recalculate total balance
    const updatedBalance = patient.balance + invoice.total - invoice.insurancePaid - invoice.amountPaid;

    const updatedPatient: Patient = {
      ...patient,
      invoices: updatedInvoices,
      balance: parseFloat(updatedBalance.toFixed(2))
    };
    onUpdatePatientData(updatedPatient);
  };

  // Update Invoice payment
  const handleUpdateInvoicePayment = (patientId: string, invId: string, amountPaid: number, status: Invoice['status']) => {
    let oldAmountPaid = 0;
    const updatedInvoices = patient.invoices.map(inv => {
      if (inv.id === invId) {
        oldAmountPaid = inv.amountPaid;
        return { ...inv, amountPaid, status };
      }
      return inv;
    });

    // Adjust balance based on the differential payment
    const diff = amountPaid - oldAmountPaid;
    const updatedBalance = Math.max(0, patient.balance - diff);

    const updatedPatient: Patient = {
      ...patient,
      invoices: updatedInvoices,
      balance: parseFloat(updatedBalance.toFixed(2))
    };
    onUpdatePatientData(updatedPatient);
  };

  // Add radiograph scan file
  const handleAddXray = (newXray: XRayFile) => {
    const updatedXrays = [...patient.xrays, newXray];
    const updatedPatient: Patient = {
      ...patient,
      xrays: updatedXrays
    };
    onUpdatePatientData(updatedPatient);
  };

  // Annotate radiograph scan
  const handleUpdateXrayAnnotations = (xrayId: string, annotations: XRayAnnotation[]) => {
    const updatedXrays = patient.xrays.map(xr => {
      if (xr.id === xrayId) {
        return { ...xr, annotations };
      }
      return xr;
    });

    const updatedPatient: Patient = {
      ...patient,
      xrays: updatedXrays
    };
    onUpdatePatientData(updatedPatient);
  };

  // Age helper
  const birthDate = new Date(patient.dob);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }

  return (
    <div className="space-y-6">
      {/* Back button and profile overview */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button
          onClick={onBackToList}
          className="flex items-center gap-1.5 py-2 px-3 border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-700 font-bold text-xs rounded-xl transition-all w-fit cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Patient List
        </button>

        <span className="text-xs font-mono font-bold text-slate-400 bg-slate-50 border border-slate-100 rounded-lg px-2.5 py-1.5 self-start md:self-auto">
          EHR PATIENT ID: {patient.id}
        </span>
      </div>

      {/* Patient demographics header card */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center gap-6 justify-between">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-red-50 border border-red-100 text-red-600 font-black text-xl flex items-center justify-center shrink-0">
              {patient.name.charAt(0)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <h2 className="text-2xl font-extrabold text-slate-900">{patient.name}</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 border border-red-100 text-red-600 capitalize">
                  {patient.gender}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 border border-red-100 text-red-600 font-mono">
                  Blood {patient.bloodType}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1.5 font-semibold flex flex-wrap items-center gap-y-1 gap-x-3.5">
                <span className="flex items-center gap-1 text-slate-500 font-bold"><Calendar className="w-3.5 h-3.5 text-slate-400" /> {patient.dob} ({age} yrs old)</span>
                <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5 text-slate-300" /> {patient.phone}</span>
                <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5 text-slate-300" /> {patient.email}</span>
              </p>
            </div>
          </div>

          {/* Address quick view */}
          <div className="text-xs text-slate-400 bg-slate-50 border border-slate-100 rounded-2xl p-3.5 max-w-sm flex items-start gap-2 lg:self-stretch">
            <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-600 text-[10px] uppercase tracking-wider">Registered Address</div>
              <p className="mt-0.5 leading-relaxed font-semibold text-slate-500">{patient.address}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main split grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Medical Alerts / History */}
        <div className="lg:col-span-3 space-y-6">
          {/* Allergies & medical warnings */}
          <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h4 className="text-xs font-black uppercase tracking-wider">Medical Allergies</h4>
            </div>
            
            {patient.allergies.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {patient.allergies.map(all => (
                  <span key={all} className="text-xs font-bold px-2.5 py-1 rounded-xl bg-red-50 border border-red-100 text-red-600 block animate-pulse">
                    {all}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 leading-relaxed font-semibold">No food, latex, chemical, or drug allergies logged for this patient.</p>
            )}
          </div>

          {/* Chronic conditions */}
          <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-amber-600">
              <HeartPulse className="w-5 h-5 shrink-0" />
              <h4 className="text-xs font-black uppercase tracking-wider">Chronic Conditions</h4>
            </div>
            
            {patient.chronicConditions.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {patient.chronicConditions.map(cond => (
                  <span key={cond} className="text-xs font-semibold px-2.5 py-1 rounded-xl bg-amber-50 border border-amber-100 text-amber-600 block">
                    {cond}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 leading-relaxed font-semibold">No systemic, cardiac, pulmonary, or diabetic conditions logged.</p>
            )}
          </div>

          {/* Emergency Contacts */}
          <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-slate-700 border-b border-slate-100 pb-2 mb-2">
              <Phone className="w-4 h-4 shrink-0 text-slate-400" />
              <h4 className="text-xs font-black uppercase tracking-wider">Emergency Contact</h4>
            </div>
            <div className="text-xs text-slate-600">
              <div className="font-bold text-slate-800">{patient.emergencyContact.name}</div>
              <div className="text-[10px] text-slate-400 font-semibold capitalize mt-0.5">{patient.emergencyContact.relationship}</div>
              <div className="mt-1.5 flex items-center gap-1 font-semibold text-red-600">
                <Phone className="w-3.5 h-3.5 shrink-0" /> {patient.emergencyContact.phone}
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Tabbed Electronic Record Area */}
        <div className="lg:col-span-9 flex flex-col space-y-6">
          {/* Custom Tabs Navigation */}
          <div className="bg-slate-100 p-1.5 rounded-2xl flex border border-slate-200 w-fit">
            <button
              onClick={() => setActiveTab('chart')}
              className={`flex items-center gap-1.5 py-2 px-4 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                activeTab === 'chart'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" /> Interactive Odontogram
            </button>

            <button
              onClick={() => setActiveTab('treatment')}
              className={`flex items-center gap-1.5 py-2 px-4 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                activeTab === 'treatment'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" /> Treatment Plan & Billing
            </button>

            <button
              onClick={() => setActiveTab('imaging')}
              className={`flex items-center gap-1.5 py-2 px-4 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                activeTab === 'imaging'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" /> Diagnostic Radiographs
            </button>
          </div>

          {/* Active Tab Component Render */}
          <div className="transition-all duration-150">
            {activeTab === 'chart' && (
              <DentalChart 
                odontogram={patient.odontogram} 
                onChange={handleChartChange} 
              />
            )}

            {activeTab === 'treatment' && (
              <TreatmentPlanner 
                patient={patient} 
                onAddTreatment={handleAddTreatment}
                onUpdateTreatmentStatus={handleUpdateTreatmentStatus}
                onDeleteTreatment={handleDeleteTreatment}
                onAddInvoice={handleAddInvoice}
                onUpdateInvoicePayment={handleUpdateInvoicePayment}
              />
            )}

            {activeTab === 'imaging' && (
              <XRayViewer 
                xrays={patient.xrays}
                onAddXray={handleAddXray}
                onUpdateXrayAnnotations={handleUpdateXrayAnnotations}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
