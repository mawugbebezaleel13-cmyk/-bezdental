/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Patient, Appointment, ClinicStats, ToothCondition } from '../types';
import clinicBanner from "../assets/images/bezdental_clinic_banner_1782612631613.jpg";
import { 
  Users, 
  Calendar, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  FileCheck, 
  Activity, 
  UserPlus, 
  Search, 
  ArrowRight,
  Sparkles,
  ChevronRight
} from 'lucide-react';

interface DashboardOverviewProps {
  patients: Patient[];
  appointments: Appointment[];
  onSelectPatient: (patientId: string) => void;
  onNavigateToTab: (tab: string) => void;
}

export default function DashboardOverview({ 
  patients, 
  appointments, 
  onSelectPatient,
  onNavigateToTab 
}: DashboardOverviewProps) {
  const [searchQuery, setSearchQuery] = useState('');

  // 1. Calculate stats dynamically
  const totalPatients = patients.length;
  const activeTreatments = patients.reduce((acc, p) => 
    acc + p.treatments.filter(t => t.status === 'in_progress' || t.status === 'planned').length, 0
  );
  
  // Today's appointments
  const todayStr = "2026-06-28"; // matches current local time set in metadata
  const todayAppointments = appointments.filter(apt => apt.dateTime.startsWith(todayStr));
  const appointmentsTodayCount = todayAppointments.length;

  // Unpaid/partial invoices sum
  const pendingBilling = patients.reduce((acc, p) => {
    const unpaidSum = p.invoices
      .filter(inv => inv.status === 'unpaid' || inv.status === 'partial')
      .reduce((s, inv) => s + (inv.total - inv.amountPaid), 0);
    return acc + unpaidSum;
  }, 0);

  // Total earnings (amountPaid in all invoices)
  const totalEarnings = patients.reduce((acc, p) => {
    return acc + p.invoices.reduce((s, inv) => s + inv.amountPaid, 0);
  }, 0);

  // Condition count breakdown
  const conditionBreakdown: Record<ToothCondition, number> = {
    healthy: 0,
    caries: 0,
    filled: 0,
    missing: 0,
    crown: 0,
    bridge: 0,
    implant: 0,
    root_canal: 0,
  };

  patients.forEach(p => {
    Object.values(p.odontogram).forEach(t => {
      Object.values(t.surfaces).forEach(cond => {
        conditionBreakdown[cond]++;
      });
    });
  });

  // Category counts
  const categoryBreakdown: Record<string, { count: number; value: number }> = {};
  patients.forEach(p => {
    p.treatments.forEach(t => {
      if (!categoryBreakdown[t.category]) {
        categoryBreakdown[t.category] = { count: 0, value: 0 };
      }
      categoryBreakdown[t.category].count++;
      categoryBreakdown[t.category].value += t.cost;
    });
  });

  // Sorted upcoming appointments
  const upcomingAppointments = appointments
    .filter(apt => apt.status === 'scheduled')
    .sort((a, b) => a.dateTime.localeCompare(b.dateTime))
    .slice(0, 5);

  // Filter patients for quick navigation
  const filteredPatients = searchQuery.trim() === ''
    ? []
    : patients.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.id.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 4);

  // SVG Line Chart coordinates helper (Patient Growth)
  // Sample month-on-month data
  const growthData = [
    { m: "Jan", c: 42 },
    { m: "Feb", c: 45 },
    { m: "Mar", c: 50 },
    { m: "Apr", c: 54 },
    { m: "May", c: 59 },
    { m: "Jun", c: 60 + totalPatients }, // grows based on patient additions
  ];

  const maxVal = Math.max(...growthData.map(d => d.c)) * 1.1;
  const chartWidth = 500;
  const chartHeight = 180;
  const padding = 30;

  const getX = (index: number) => padding + (index / (growthData.length - 1)) * (chartWidth - padding * 2);
  const getY = (count: number) => chartHeight - padding - ((count) / maxVal) * (chartHeight - padding * 2);

  const linePath = growthData.reduce((path, d, i) => {
    return path + `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.c)} `;
  }, '');

  return (
    <div className="space-y-6">
      {/* Dynamic Header */}
      <div className="relative rounded-3xl overflow-hidden shadow-md bg-slate-950 text-white min-h-[220px] flex items-center">
        {/* Background Banner Image with Dark Vignette/Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src={clinicBanner} 
            alt="BezDental Clinic" 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-transparent"></div>
        </div>

        <div className="relative z-10 p-6 xl:p-8 flex flex-col md:flex-row md:items-center md:justify-between gap-6 w-full">
          <div>
            <div className="flex items-center gap-2 bg-red-500/15 border border-red-500/30 w-fit px-3 py-1 rounded-full text-red-400 text-xs font-bold">
              <Sparkles className="w-3 h-3" />
              <span>BezDental Clinic • Accra, Ghana</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight mt-3">Welcome, Dr. Bezaleel Mawutorwu Mawugbe</h1>
            <p className="text-slate-300 text-sm mt-1.5 max-w-xl">
              Head Dentist & Oral Surgeon • <span className="text-red-400 font-bold">mawugbebezaleel13@gmail.com</span> • <span className="text-red-400 font-bold">(0256488754)</span>
            </p>
            <p className="text-slate-400 text-xs mt-1.5 max-w-xl">
              Under your expert care, manage interactive EHR odontograms, dental scans, scheduling, and billing analytics in Ghana Cedis.
            </p>
          </div>

          {/* Quick search */}
          <div className="w-full md:w-80 relative">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              placeholder="Search patients by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-950/95 border border-slate-800 text-white rounded-xl focus:outline-none focus:border-red-500 text-sm placeholder-slate-500 transition-all shadow-lg"
            />
            
            {/* Search Dropdown */}
            {filteredPatients.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-slate-950 border border-slate-800 rounded-xl shadow-xl overflow-hidden z-20">
                <div className="p-2 bg-slate-900 text-[10px] uppercase tracking-wider font-semibold text-slate-500 border-b border-slate-800">
                  Patient Match Results
                </div>
                {filteredPatients.map(p => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectPatient(p.id);
                      setSearchQuery('');
                    }}
                    className="w-full flex items-center justify-between text-left px-4 py-2.5 hover:bg-slate-800 text-xs border-b border-slate-900/50 transition-colors"
                  >
                    <div>
                      <div className="font-bold text-white">{p.name}</div>
                      <div className="text-slate-500 text-[10px] mt-0.5">{p.id} • {p.phone}</div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-red-500" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Patients card */}
        <div 
          onClick={() => onNavigateToTab('patients')}
          className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md cursor-pointer transition-all hover:translate-y-[-2px] group"
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Patients</p>
              <h3 className="text-2xl font-black text-slate-900 mt-2">{totalPatients}</h3>
            </div>
            <div className="p-3 bg-red-50 text-red-600 rounded-xl group-hover:bg-red-600 group-hover:text-white transition-all">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-red-600 font-semibold mt-4">
            <UserPlus className="w-3.5 h-3.5" />
            <span>Click to manage records</span>
          </div>
        </div>

        {/* Active treatments card */}
        <div 
          onClick={() => onNavigateToTab('patients')}
          className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md cursor-pointer transition-all hover:translate-y-[-2px] group"
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Active Procedures</p>
              <h3 className="text-2xl font-black text-slate-900 mt-2">{activeTreatments}</h3>
            </div>
            <div className="p-3 bg-red-50/70 text-red-700 rounded-xl group-hover:bg-red-600 group-hover:text-white transition-all">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-red-600 font-semibold mt-4">
            <FileCheck className="w-3.5 h-3.5" />
            <span>Treatments, Fillings, Implants</span>
          </div>
        </div>

        {/* Today's schedule */}
        <div 
          onClick={() => onNavigateToTab('appointments')}
          className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md cursor-pointer transition-all hover:translate-y-[-2px] group"
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Appointments Today</p>
              <h3 className="text-2xl font-black text-slate-900 mt-2">{appointmentsTodayCount}</h3>
            </div>
            <div className="p-3 bg-red-50 text-red-600 rounded-xl group-hover:bg-red-600 group-hover:text-white transition-all">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-red-600 font-semibold mt-4">
            <Clock className="w-3.5 h-3.5" />
            <span>Click to view calendar</span>
          </div>
        </div>

        {/* Pending Invoices */}
        <div 
          onClick={() => onNavigateToTab('patients')}
          className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md cursor-pointer transition-all hover:translate-y-[-2px] group"
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Pending Balance</p>
              <h3 className="text-2xl font-black text-slate-900 mt-2">GH₵{pendingBilling.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</h3>
            </div>
            <div className="p-3 bg-red-50 text-red-600 rounded-xl group-hover:bg-red-600 group-hover:text-white transition-all">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-red-600 font-semibold mt-4">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Clinic Revenue: GH₵{totalEarnings.toLocaleString(undefined, {maximumFractionDigits: 0})} total</span>
          </div>
        </div>
      </div>

      {/* Visual Analytics & Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Patient Intake Over Time (SVG Chart) */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm lg:col-span-7 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">Patient Intake Growth</h3>
            <p className="text-xs text-slate-400">Total registered patients month-over-month (Q1-Q2 2026)</p>
          </div>

          <div className="py-6 flex justify-center items-center overflow-x-auto">
            <svg width={chartWidth} height={chartHeight} viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="max-w-full">
              {/* Grid Lines */}
              {[0, 1, 2, 3, 4].map((grid, j) => {
                const yVal = padding + (j / 4) * (chartHeight - padding * 2);
                const countVal = Math.round(maxVal - (j / 4) * maxVal);
                return (
                  <g key={grid} className="stroke-slate-100">
                    <line x1={padding} y1={yVal} x2={chartWidth - padding} y2={yVal} strokeWidth="1" />
                    <text x={padding - 5} y={yVal + 4} stroke="none" fill="#94a3b8" className="text-[10px] text-right font-semibold" textAnchor="end">
                      {countVal}
                    </text>
                  </g>
                );
              })}

              {/* Chart Line Path */}
              <path d={linePath} fill="none" stroke="url(#paint_gradient)" strokeWidth="3.5" strokeLinecap="round" />

              {/* Area Under Curve Fill */}
              <path
                d={`${linePath} L ${getX(growthData.length - 1)} ${chartHeight - padding} L ${getX(0)} ${chartHeight - padding} Z`}
                fill="url(#paint_area_gradient)"
                stroke="none"
              />

              {/* Gradients */}
              <defs>
                <linearGradient id="paint_gradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#dc2626" />
                  <stop offset="100%" stopColor="#f43f5e" />
                </linearGradient>
                <linearGradient id="paint_area_gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#dc2626" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#dc2626" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Glowing Interactive Dots */}
              {growthData.map((d, i) => (
                <g key={i}>
                  <circle cx={getX(i)} cy={getY(d.c)} r="7" className="fill-white stroke-red-500 stroke-2 shadow-sm" />
                  <circle cx={getX(i)} cy={getY(d.c)} r="3" className="fill-red-600" />
                  <text x={getX(i)} y={getY(d.c) - 12} fill="#1e293b" className="text-[10px] font-bold text-center" textAnchor="middle">
                    {d.c}
                  </text>
                  <text x={getX(i)} y={chartHeight - padding + 15} fill="#64748b" className="text-[10px] font-semibold" textAnchor="middle">
                    {d.m}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>

        {/* Conditions Statistics */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm lg:col-span-5 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">Prevalent Tooth Statuses</h3>
            <p className="text-xs text-slate-400">Analysis of documented conditions across active patients</p>
          </div>

          <div className="space-y-3.5 my-4">
            {/* Render a custom visual bar chart */}
            {Object.entries(conditionBreakdown)
              .filter(([cond]) => cond !== 'healthy') // skip healthy to focus on issues
              .sort((a, b) => b[1] - a[1])
              .slice(0, 5)
              .map(([cond, count]) => {
                const colors: Record<string, string> = {
                  caries: 'bg-red-500',
                  filled: 'bg-blue-500',
                  missing: 'bg-slate-300',
                  crown: 'bg-amber-400',
                  bridge: 'bg-purple-400',
                  implant: 'bg-rose-500',
                  root_canal: 'bg-emerald-500',
                };
                const totalNonHealthy = Object.entries(conditionBreakdown)
                  .filter(([k]) => k !== 'healthy')
                  .reduce((sum, [, val]) => sum + val, 0) || 1;

                const percent = Math.round((count / totalNonHealthy) * 100);

                return (
                  <div key={cond} className="space-y-1">
                    <div className="flex justify-between items-center text-xs font-semibold">
                      <span className="capitalize text-slate-600 flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${colors[cond]}`}></span>
                        {cond.replace('_', ' ')}
                      </span>
                      <span className="text-slate-900">{count} teeth ({percent}%)</span>
                    </div>
                    <div className="h-2 w-full bg-slate-50 rounded-full overflow-hidden border border-slate-100">
                      <div className={`h-full ${colors[cond]} rounded-full`} style={{ width: `${percent}%` }}></div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {/* Appointment Timeline Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Upcoming appointments calendar feed */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm lg:col-span-7">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">Upcoming Appointments</h3>
              <p className="text-xs text-slate-400">Scheduled clinical appointments for the next week</p>
            </div>
            <button
              onClick={() => onNavigateToTab('appointments')}
              className="text-xs font-bold text-red-600 hover:text-red-700 hover:underline flex items-center gap-1"
            >
              Full Calendar <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3.5">
            {upcomingAppointments.length > 0 ? (
              upcomingAppointments.map(apt => {
                // Parse date
                const dateObj = new Date(apt.dateTime);
                const isToday = apt.dateTime.startsWith(todayStr);

                return (
                  <div 
                    key={apt.id}
                    onClick={() => onSelectPatient(apt.patientId)}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-xl border border-slate-100 hover:border-red-500/30 hover:bg-red-50/10 cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      {/* Time Block */}
                      <div className={`w-24 text-center py-1.5 rounded-lg shrink-0 ${
                        isToday ? 'bg-red-50 border border-red-100' : 'bg-slate-50 border border-slate-100'
                      }`}>
                        <div className={`text-[10px] font-bold uppercase tracking-wide ${isToday ? 'text-red-600' : 'text-slate-400'}`}>
                          {isToday ? 'TODAY' : dateObj.toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}
                        </div>
                        <div className={`text-xs font-black mt-0.5 ${isToday ? 'text-red-900' : 'text-slate-700'}`}>
                          {dateObj.toLocaleTimeString(undefined, {hour: '2-digit', minute: '2-digit', hour12: true})}
                        </div>
                      </div>

                      {/* Patient & Reason */}
                      <div>
                        <div className="font-bold text-sm text-slate-900 hover:text-red-600 transition-colors">{apt.patientName}</div>
                        <div className="text-xs text-slate-500 mt-0.5 font-medium flex items-center gap-1">
                          <span className="text-slate-400">{apt.reason}</span>
                          <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded font-medium">{apt.dentistName}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mt-3 sm:mt-0">
                      <span className="text-[10px] text-slate-400 font-semibold">{apt.duration} min</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 border border-red-100 text-red-600 capitalize">
                        {apt.status}
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-center py-8 text-slate-400 text-xs">
                No upcoming appointments scheduled.
              </div>
            )}
          </div>
        </div>

        {/* Treatment Distribution Summary */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm lg:col-span-5 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">Treatment Revenue</h3>
            <p className="text-xs text-slate-400">Clinic treatment value distributions by categories</p>
          </div>

          <div className="space-y-4 my-5 flex-1 flex flex-col justify-center">
            {Object.keys(categoryBreakdown).length > 0 ? (
              Object.entries(categoryBreakdown)
                .sort((a, b) => b[1].value - a[1].value)
                .slice(0, 4)
                .map(([cat, info]) => {
                  return (
                    <div key={cat} className="flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex justify-between items-center text-xs font-semibold mb-1">
                          <span className="text-slate-700 font-bold">{cat}</span>
                          <span className="text-slate-900">GH₵{info.value.toLocaleString()}</span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-50 rounded-full">
                          <div 
                            className="h-full bg-red-600 rounded-full" 
                            style={{ width: `${Math.min(100, (info.value / (totalEarnings || 5000)) * 100)}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="text-[10px] font-semibold text-slate-400 bg-slate-50 border border-slate-100 rounded px-2 py-1 shrink-0">
                        {info.count} cases
                      </div>
                    </div>
                  );
                })
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs">
                No treatment distribution data logged yet.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
