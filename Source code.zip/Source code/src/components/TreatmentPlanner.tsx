/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Patient, TreatmentItem, Invoice, InvoiceItem } from '../types';
import { PROCEDURE_TEMPLATES } from '../sampleData';
import { 
  Plus, 
  Trash2, 
  Check, 
  FileText, 
  DollarSign, 
  CreditCard, 
  Percent, 
  Printer, 
  Layers, 
  RefreshCw,
  TrendingDown
} from 'lucide-react';

interface TreatmentPlannerProps {
  patient: Patient;
  onAddTreatment: (patientId: string, item: TreatmentItem) => void;
  onUpdateTreatmentStatus: (patientId: string, txId: string, status: TreatmentItem['status']) => void;
  onDeleteTreatment: (patientId: string, txId: string) => void;
  onAddInvoice: (patientId: string, invoice: Invoice) => void;
  onUpdateInvoicePayment: (patientId: string, invId: string, amountPaid: number, status: Invoice['status']) => void;
  readOnly?: boolean;
}

export default function TreatmentPlanner({
  patient,
  onAddTreatment,
  onUpdateTreatmentStatus,
  onDeleteTreatment,
  onAddInvoice,
  onUpdateInvoicePayment,
  readOnly = false
}: TreatmentPlannerProps) {
  // Treatment Form State
  const [procedureCode, setProcedureCode] = useState(PROCEDURE_TEMPLATES[0].code);
  const [customPrice, setCustomPrice] = useState<number>(PROCEDURE_TEMPLATES[0].cost);
  const [treatmentNotes, setTreatmentNotes] = useState('');

  // Invoice Form State
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [selectedTxIds, setSelectedTxIds] = useState<string[]>([]);
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [taxPercent, setTaxPercent] = useState<number>(5);
  const [insuranceCoverage, setInsuranceCoverage] = useState<number>(0);
  const [amountPaidNow, setAmountPaidNow] = useState<number>(0);

  // Print/Receipt View state
  const [selectedReceiptId, setSelectedReceiptId] = useState<string | null>(null);

  const handleProcedureChange = (code: string) => {
    setProcedureCode(code);
    const template = PROCEDURE_TEMPLATES.find(p => p.code === code);
    if (template) {
      setCustomPrice(template.cost);
    }
  };

  const handleCreateTreatment = (e: React.FormEvent) => {
    e.preventDefault();
    if (readOnly) return;

    const template = PROCEDURE_TEMPLATES.find(p => p.code === procedureCode);
    if (!template) return;

    const newTx: TreatmentItem = {
      id: `TX-0${patient.treatments.length + 10}`,
      code: template.code,
      name: template.name,
      category: template.category as any,
      cost: customPrice,
      notes: treatmentNotes,
      status: 'planned',
      date: new Date().toISOString().split('T')[0]
    };

    onAddTreatment(patient.id, newTx);
    setTreatmentNotes('');
  };

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedTxIds.length === 0 || readOnly) return;

    // Filter matching treatments
    const invoiceTreatments = patient.treatments.filter(t => selectedTxIds.includes(t.id));
    
    // Construct items list
    const items: InvoiceItem[] = invoiceTreatments.map(t => ({
      name: `${t.name} (${t.code})`,
      cost: t.cost
    }));

    // Math
    const subtotal = invoiceTreatments.reduce((sum, t) => sum + t.cost, 0);
    const discountAmount = subtotal * (discountPercent / 100);
    const subtotalAfterDiscount = subtotal - discountAmount;
    const taxAmount = subtotalAfterDiscount * (taxPercent / 100);
    const total = parseFloat((subtotalAfterDiscount + taxAmount).toFixed(2));

    // Status checking
    const outstanding = total - insuranceCoverage;
    const payment = Math.min(outstanding, amountPaidNow);
    let status: Invoice['status'] = 'unpaid';
    if (payment >= outstanding && outstanding > 0) {
      status = 'paid';
    } else if (payment > 0) {
      status = 'partial';
    }

    const newInvoice: Invoice = {
      id: `INV-0${patient.invoices.length + 10}`,
      patientId: patient.id,
      date: new Date().toISOString().split('T')[0],
      items,
      discount: discountPercent,
      tax: taxPercent,
      total,
      insurancePaid: insuranceCoverage,
      amountPaid: payment,
      status
    };

    onAddInvoice(patient.id, newInvoice);

    // Reset Form
    setSelectedTxIds([]);
    setDiscountPercent(0);
    setInsuranceCoverage(0);
    setAmountPaidNow(0);
    setShowInvoiceForm(false);
  };

  const activeReceipt = patient.invoices.find(inv => inv.id === selectedReceiptId);

  return (
    <div className="space-y-6">
      {/* Overview totals */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Outstanding Balance</span>
          <div className="text-2xl font-black text-red-600 mt-1">
            GH₵{patient.balance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
          </div>
          <span className="text-[10px] text-slate-400 mt-1.5 block">Pending insurance or patient payment.</span>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Completed Procedures</span>
          <div className="text-2xl font-black text-slate-800 mt-1">
            {patient.treatments.filter(t => t.status === 'completed').length} / {patient.treatments.length}
          </div>
          <span className="text-[10px] text-slate-400 mt-1.5 block">Total logged dental treatments.</span>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Invoiced Billing</span>
          <div className="text-2xl font-black text-red-700 mt-1">
            GH₵{patient.invoices.reduce((sum, inv) => sum + inv.total, 0).toLocaleString(undefined, {maximumFractionDigits: 2})}
          </div>
          <span className="text-[10px] text-slate-400 mt-1.5 block">Sum of all compiled statements.</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Treatment Log & Actions */}
        <div className="xl:col-span-8 space-y-6">
          {/* Treatment items table */}
          <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
            <div className="bg-slate-50 border-b border-slate-100 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">Treatment Log Plan</h4>
                <p className="text-[10px] text-slate-500 mt-0.5">Clinical procedures and restorative actions designed for this patient.</p>
              </div>

              {!readOnly && (
                <button
                  onClick={() => setShowInvoiceForm(true)}
                  className="flex items-center gap-1 py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white font-semibold text-xs rounded-lg transition-colors shadow-sm cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" /> Compile New Invoice
                </button>
              )}
            </div>

            {patient.treatments.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-wider bg-slate-50/50">
                      <th className="py-3 px-6">Date</th>
                      <th className="py-3 px-6">Code / Name</th>
                      <th className="py-3 px-6">Category</th>
                      <th className="py-3 px-6 text-right">Cost</th>
                      <th className="py-3 px-6 text-center">Status</th>
                      {!readOnly && <th className="py-3 px-6 text-center">Actions</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {patient.treatments.map(t => (
                      <tr key={t.id} className="hover:bg-slate-50/20">
                        <td className="py-4 px-6 text-slate-500">{t.date}</td>
                        <td className="py-4 px-6">
                          <div className="font-bold text-slate-900">{t.name}</div>
                          <div className="font-mono text-[10px] text-slate-400 mt-0.5">{t.code}</div>
                          {t.notes && <p className="text-[10px] text-slate-400 mt-1 italic">Note: {t.notes}</p>}
                        </td>
                        <td className="py-4 px-6">
                          <span className="font-semibold text-slate-500">{t.category}</span>
                        </td>
                        <td className="py-4 px-6 text-right font-bold text-slate-900">GH₵{t.cost.toLocaleString()}</td>
                        <td className="py-4 px-6 text-center">
                          <span className={`px-2 py-0.5 rounded-full font-bold text-[9px] capitalize ${
                            t.status === 'completed'
                              ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                              : t.status === 'in_progress'
                              ? 'bg-blue-50 text-blue-600 border border-blue-100'
                              : 'bg-amber-50 text-amber-600 border border-amber-100'
                          }`}>
                            {t.status.replace('_', ' ')}
                          </span>
                        </td>
                        {!readOnly && (
                          <td className="py-4 px-6 text-center">
                            <div className="flex items-center justify-center gap-1 bg-slate-50 border border-slate-100 p-1 rounded-lg w-fit mx-auto">
                              {t.status !== 'completed' && (
                                <button
                                  onClick={() => onUpdateTreatmentStatus(patient.id, t.id, 'completed')}
                                  className="p-1 hover:bg-emerald-500 hover:text-white rounded transition-colors text-slate-400"
                                  title="Mark Completed"
                                >
                                  <Check className="w-3 h-3" />
                                </button>
                              )}
                              {t.status === 'planned' && (
                                <button
                                  onClick={() => onUpdateTreatmentStatus(patient.id, t.id, 'in_progress')}
                                  className="p-1 hover:bg-blue-500 hover:text-white rounded transition-colors text-slate-400"
                                  title="Mark In Progress"
                                >
                                  <RefreshCw className="w-3 h-3" />
                                </button>
                              )}
                              <button
                                onClick={() => onDeleteTreatment(patient.id, t.id)}
                                className="p-1 hover:bg-red-500 hover:text-white rounded transition-colors text-slate-400"
                                title="Remove Treatment"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-10 text-xs text-slate-400">
                No treatment plan or procedure logs recorded yet.
              </div>
            )}
          </div>

          {/* Add Treatment Plan Form */}
          {!readOnly && (
            <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
              <h4 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 mb-4">Add Procedure to Treatment Plan</h4>
              <form onSubmit={handleCreateTreatment} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                {/* Selector */}
                <div className="md:col-span-5">
                  <label className="text-xs font-bold text-slate-500 block mb-1">Standard Dental Procedure</label>
                  <select
                    value={procedureCode}
                    onChange={(e) => handleProcedureChange(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 bg-white"
                  >
                    {PROCEDURE_TEMPLATES.map(proc => (
                      <option key={proc.code} value={proc.code}>
                        {proc.name} ({proc.code})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Customized Cost */}
                <div className="md:col-span-3">
                  <label className="text-xs font-bold text-slate-500 block mb-1">Clinic Cost (GH₵)</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 font-bold text-xs pointer-events-none">GH₵</span>
                    <input
                      type="number"
                      required
                      value={customPrice}
                      onChange={(e) => setCustomPrice(parseInt(e.target.value) || 0)}
                      className="w-full text-xs pl-12 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>

                {/* Notes */}
                <div className="md:col-span-4">
                  <label className="text-xs font-bold text-slate-500 block mb-1">Special Clinical Notes (optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. Tooth #14 mesial pit, anesthetic used"
                    value={treatmentNotes}
                    onChange={(e) => setTreatmentNotes(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>

                <div className="md:col-span-12 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-1 py-2 px-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-lg shadow-sm transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> Log Treatment
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>

        {/* Invoices List / Billings Sidebar */}
        <div className="xl:col-span-4 space-y-4">
          <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Invoices & Statements</h4>
            {patient.invoices.length > 0 ? (
              <div className="space-y-3">
                {patient.invoices.map(inv => {
                  const itemsCount = inv.items.length;
                  const remaining = inv.total - inv.insurancePaid - inv.amountPaid;

                  return (
                    <div 
                      key={inv.id}
                      className="p-3.5 border border-slate-100 hover:border-red-500/20 rounded-xl transition-all flex flex-col justify-between text-xs"
                    >
                      <div className="flex justify-between items-start border-b border-slate-50 pb-2 mb-2">
                        <div>
                          <span className="font-mono text-[10px] font-bold text-slate-400">{inv.id}</span>
                          <span className="text-[10px] text-slate-400 ml-1">({inv.date})</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[8px] uppercase ${
                          inv.status === 'paid'
                            ? 'bg-emerald-50 text-emerald-600'
                            : inv.status === 'partial'
                            ? 'bg-blue-50 text-blue-600'
                            : 'bg-red-50 text-red-600'
                        }`}>
                          {inv.status}
                        </span>
                      </div>

                      <div className="space-y-1 text-slate-500 font-medium">
                        <div className="flex justify-between"><span>Subtotal items ({itemsCount})</span><span className="font-semibold text-slate-700">GH₵{inv.total.toFixed(2)}</span></div>
                        {inv.insurancePaid > 0 && (
                          <div className="flex justify-between"><span>Insurance covered</span><span className="text-red-600">-GH₵{inv.insurancePaid.toFixed(2)}</span></div>
                        )}
                        <div className="flex justify-between"><span>Amount paid</span><span className="text-slate-800">GH₵{inv.amountPaid.toFixed(2)}</span></div>
                        {remaining > 0 && (
                          <div className="flex justify-between border-t border-slate-50/50 pt-1 mt-1 font-bold">
                            <span className="text-red-600">Patient Due</span>
                            <span className="text-red-600">GH₵{remaining.toFixed(2)}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-1 mt-3.5">
                        <button
                          onClick={() => setSelectedReceiptId(inv.id)}
                          className="flex-1 flex items-center justify-center gap-1 py-1 px-2 border border-slate-200 hover:bg-slate-50 text-slate-600 font-bold text-[10px] rounded cursor-pointer"
                        >
                          <Printer className="w-3 h-3" /> Receipt Invoice
                        </button>
                        
                        {!readOnly && inv.status !== 'paid' && (
                          <button
                            onClick={() => {
                              const payAmount = prompt(`Enter payment amount to record. Outstanding: GH₵${remaining.toFixed(2)}`);
                              if (payAmount === null) return;
                              const amt = parseFloat(payAmount);
                              if (isNaN(amt) || amt <= 0) {
                                alert("Invalid payment amount entered.");
                                return;
                              }
                              
                              const newAmountPaid = inv.amountPaid + amt;
                              const newRemaining = inv.total - inv.insurancePaid - newAmountPaid;
                              let newStatus: Invoice['status'] = 'partial';
                              if (newRemaining <= 0) {
                                newStatus = 'paid';
                              }
                              onUpdateInvoicePayment(patient.id, inv.id, newAmountPaid, newStatus);
                            }}
                            className="flex-1 py-1 px-2 bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] rounded text-center cursor-pointer"
                          >
                            Add Pay
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-xs text-slate-400">
                No invoices statement compiled yet.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Compile Invoice Overlay Modal */}
      {showInvoiceForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white border border-slate-100 rounded-2xl shadow-xl w-full max-w-xl p-6 relative max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => setShowInvoiceForm(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-xl font-bold p-1 hover:bg-slate-50 rounded-lg"
            >
              &times;
            </button>

            <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3 mb-4">Compile Patient Invoice</h3>

            <form onSubmit={handleCreateInvoice} className="space-y-4">
              {/* Treatments Selector */}
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-2">Select Procedures to Invoice *</label>
                <div className="space-y-2 max-h-[160px] overflow-y-auto border border-slate-100 rounded-xl p-2.5 bg-slate-50/50">
                  {patient.treatments.map(t => {
                    const isChecked = selectedTxIds.includes(t.id);
                    return (
                      <label key={t.id} className="flex items-center gap-2 text-xs font-semibold cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              setSelectedTxIds(selectedTxIds.filter(id => id !== t.id));
                            } else {
                              setSelectedTxIds([...selectedTxIds, t.id]);
                            }
                          }}
                          className="rounded text-red-600 focus:ring-red-500 w-3.5 h-3.5"
                        />
                        <span className="flex-1 text-slate-700">{t.name} ({t.code})</span>
                        <span className="text-slate-900">GH₵{t.cost.toLocaleString()}</span>
                      </label>
                    );
                  })}
                  {patient.treatments.length === 0 && (
                    <div className="text-center py-4 text-xs text-slate-400">No active treatments found to bill.</div>
                  )}
                </div>
              </div>

              {/* Discount / Taxes */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-500 block mb-1">Discount Rate (%)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(parseInt(e.target.value) || 0)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-500 block mb-1">Clinical Taxes (%)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={taxPercent}
                    onChange={(e) => setTaxPercent(parseInt(e.target.value) || 0)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Insurance Coverage */}
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Insurance Paid Co-pay Allocation (GH₵)</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 font-bold text-xs pointer-events-none">GH₵</span>
                  <input
                    type="number"
                    min="0"
                    value={insuranceCoverage}
                    onChange={(e) => setInsuranceCoverage(parseFloat(e.target.value) || 0)}
                    className="w-full text-xs pl-12 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Amount paid today */}
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Patient Deposit Payment Received (GH₵)</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 font-bold text-xs pointer-events-none">GH₵</span>
                  <input
                    type="number"
                    min="0"
                    value={amountPaidNow}
                    onChange={(e) => setAmountPaidNow(parseFloat(e.target.value) || 0)}
                    className="w-full text-xs pl-12 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Compile and Save */}
              <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={() => setShowInvoiceForm(false)}
                  className="py-2 px-3 border border-slate-200 hover:bg-slate-50 text-slate-500 font-bold text-xs rounded-lg transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={selectedTxIds.length === 0}
                  className="py-2 px-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-lg shadow-sm transition-all disabled:opacity-40 cursor-pointer"
                >
                  Confirm & Lock Statement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Styled Printable Receipt Modal */}
      {selectedReceiptId && activeReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white border border-slate-100 rounded-3xl shadow-xl w-full max-w-lg p-6 md:p-8 relative">
            <button
              onClick={() => setSelectedReceiptId(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-xl font-bold p-1 hover:bg-slate-50 rounded-lg print:hidden"
            >
              &times;
            </button>

            {/* Receipt container targeting printing */}
            <div id="printable-receipt" className="space-y-6">
              {/* Receipt Header */}
              <div className="text-center pb-4 border-b border-dashed border-slate-200">
                <div className="text-sm font-bold tracking-widest text-red-600 uppercase">BezDental Clinic</div>
                <h4 className="text-xs font-semibold text-slate-400 mt-1">No. 45 Anumsa Street, East Legon, Accra</h4>
                <p className="text-[10px] text-slate-400 mt-0.5">Phone: +233 24 123 4567 • BezDental</p>
              </div>

              {/* Bill to metadata */}
              <div className="grid grid-cols-2 gap-4 text-[10px] text-slate-500">
                <div>
                  <div className="font-bold text-slate-400 uppercase tracking-wide">Patient Details</div>
                  <div className="font-bold text-slate-800 text-xs mt-1">{patient.name}</div>
                  <div className="mt-0.5">{patient.phone}</div>
                  <div>ID: {patient.id}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-slate-400 uppercase tracking-wide">Receipt metadata</div>
                  <div className="font-bold text-slate-800 text-xs mt-1">Invoice {activeReceipt.id}</div>
                  <div className="mt-0.5">Date: {activeReceipt.date}</div>
                  <div>Status: <span className="font-bold uppercase">{activeReceipt.status}</span></div>
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-2 border-t border-b border-slate-100 py-3 text-xs">
                {activeReceipt.items.map((item, index) => (
                  <div key={index} className="flex justify-between font-medium">
                    <span className="text-slate-600">{item.name}</span>
                    <span className="text-slate-900 font-bold">GH₵{item.cost.toFixed(2)}</span>
                  </div>
                ))}
              </div>

              {/* Invoice calculation sub-lines */}
              <div className="space-y-1.5 text-right text-xs text-slate-500">
                {activeReceipt.discount > 0 && (
                  <div>
                    <span>Professional Discount ({activeReceipt.discount}%):</span>
                    <span className="font-semibold text-slate-800 ml-2">
                      -GH₵{(activeReceipt.items.reduce((s,i) => s+i.cost, 0) * (activeReceipt.discount/100)).toFixed(2)}
                    </span>
                  </div>
                )}
                <div>
                  <span>Taxes ({activeReceipt.tax}%):</span>
                  <span className="font-semibold text-slate-800 ml-2">GH₵{(activeReceipt.total * (activeReceipt.tax/100)).toFixed(2)}</span>
                </div>
                <div className="text-slate-900 font-extrabold text-sm border-t border-slate-100 pt-1.5 mt-1.5 flex justify-between">
                  <span>Grand Total Bill:</span>
                  <span>GH₵{activeReceipt.total.toFixed(2)}</span>
                </div>

                {/* Insurance / Copay details */}
                {activeReceipt.insurancePaid > 0 && (
                  <div className="text-red-600 font-semibold text-[11px] flex justify-between">
                    <span>Insurance Paid Allowance:</span>
                    <span>-GH₵{activeReceipt.insurancePaid.toFixed(2)}</span>
                  </div>
                )}

                <div className="text-red-700 font-semibold text-[11px] flex justify-between">
                  <span>Patient Payments Received:</span>
                  <span>-GH₵{activeReceipt.amountPaid.toFixed(2)}</span>
                </div>

                {activeReceipt.total - activeReceipt.insurancePaid - activeReceipt.amountPaid > 0 && (
                  <div className="text-red-600 font-black text-xs border-t border-dashed border-slate-200 pt-1.5 mt-1.5 flex justify-between">
                    <span>Outstanding Balance Due:</span>
                    <span>GH₵{(activeReceipt.total - activeReceipt.insurancePaid - activeReceipt.amountPaid).toFixed(2)}</span>
                  </div>
                )}
              </div>

              {/* Receipt Footer */}
              <div className="text-center pt-4 border-t border-dashed border-slate-200 text-[10px] text-slate-400 italic leading-relaxed">
                Thank you for choosing BezDental Clinic. Keep this copy for tax or medical insurance claim reimbursement.
              </div>
            </div>

            {/* Print trigger button */}
            <div className="flex gap-2 justify-end mt-6 print:hidden">
              <button
                onClick={() => setSelectedReceiptId(null)}
                className="py-2 px-4 border border-slate-200 hover:bg-slate-50 text-slate-500 font-bold text-xs rounded-xl transition-all"
              >
                Close Receipt
              </button>
              <button
                onClick={() => window.print()}
                className="flex items-center gap-1.5 py-2 px-4 bg-slate-900 hover:bg-slate-850 text-white font-bold text-xs rounded-xl shadow-sm transition-all"
              >
                <Printer className="w-4 h-4" /> Print Document
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
