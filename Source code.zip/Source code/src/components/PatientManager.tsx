/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Patient } from '../types';
import { createEmptyOdontogram } from '../sampleData';
import { 
  Plus, 
  Search, 
  Filter, 
  Trash2, 
  ChevronRight, 
  User, 
  AlertTriangle, 
  Clock, 
  Phone, 
  Mail, 
  MapPin,
  Calendar
} from 'lucide-react';

interface PatientManagerProps {
  patients: Patient[];
  onSelectPatient: (patientId: string) => void;
  onAddPatient: (newPatient: Patient) => void;
  onDeletePatient: (patientId: string) => void;
}

export default function PatientManager({ 
  patients, 
  onSelectPatient, 
  onAddPatient,
  onDeletePatient 
}: PatientManagerProps) {
  const [search, setSearch] = useState('');
  const [filterGender, setFilterGender] = useState<string>('all');
  const [filterCondition, setFilterCondition] = useState<string>('all');
  const [showAddForm, setShowAddForm] = useState(false);

  // New patient state
  const [newName, setNewName] = useState('');
  const [newDob, setNewDob] = useState('');
  const [newGender, setNewGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newAddress, setNewAddress] = useState('');
  const [newBloodType, setNewBloodType] = useState('O+');
  const [newAllergies, setNewAllergies] = useState('');
  const [newConditions, setNewConditions] = useState('');
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyRelationship, setEmergencyRelationship] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');

  // Handle Form Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newDob) return;

    const parseCommaString = (str: string) => 
      str ? str.split(',').map(s => s.trim()).filter(s => s.length > 0) : [];

    const newPatient: Patient = {
      id: `PAT-0${patients.length + 11}`,
      name: newName,
      dob: newDob,
      gender: newGender,
      phone: newPhone || '+233 24 000 0000',
      email: newEmail || 'patient@email.gh',
      address: newAddress || 'No. 12 Ring Road Central, Osu, Accra, Ghana',
      bloodType: newBloodType,
      allergies: parseCommaString(newAllergies),
      chronicConditions: parseCommaString(newConditions),
      emergencyContact: {
        name: emergencyName || 'Emergency Contact',
        relationship: emergencyRelationship || 'Spouse',
        phone: emergencyPhone || '+233 24 000 0000'
      },
      odontogram: createEmptyOdontogram(),
      treatments: [],
      xrays: [],
      invoices: [],
      balance: 0
    };

    onAddPatient(newPatient);
    
    // Reset state
    setNewName('');
    setNewDob('');
    setNewGender('Male');
    setNewPhone('');
    setNewEmail('');
    setNewAddress('');
    setNewBloodType('O+');
    setNewAllergies('');
    setNewConditions('');
    setEmergencyName('');
    setEmergencyRelationship('');
    setEmergencyPhone('');
    setShowAddForm(false);
  };

  // Filter & Search Logic
  const filteredPatients = patients.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                        p.id.toLowerCase().includes(search.toLowerCase()) ||
                        p.phone.includes(search);
    const matchGender = filterGender === 'all' || p.gender === filterGender;
    
    let matchCondition = true;
    if (filterCondition === 'balance') {
      matchCondition = p.balance > 0;
    } else if (filterCondition === 'allergies') {
      matchCondition = p.allergies.length > 0;
    } else if (filterCondition === 'chronic') {
      matchCondition = p.chronicConditions.length > 0;
    }

    return matchSearch && matchGender && matchCondition;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filters Header */}
      <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Patient Registry Database</h2>
            <p className="text-xs text-slate-400 mt-1">Search, register, and manage electronic health records (EHR) for active clients.</p>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center justify-center gap-1.5 py-2.5 px-4 bg-red-600 hover:bg-red-500 text-white font-bold text-sm rounded-xl shadow-sm transition-all shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Register New Patient
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mt-6">
          {/* Search */}
          <div className="relative md:col-span-6">
            <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 pointer-events-none">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              placeholder="Search by name, patient ID, phone..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500 text-sm text-slate-700 placeholder-slate-400 transition-colors"
            />
          </div>

          {/* Gender Filter */}
          <div className="relative md:col-span-3">
            <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 pointer-events-none">
              <Filter className="w-4 h-4" />
            </span>
            <select
              value={filterGender}
              onChange={(e) => setFilterGender(e.target.value)}
              className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500 text-sm text-slate-700 font-medium cursor-pointer transition-colors appearance-none"
            >
              <option value="all">All Genders</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {/* Condition Filter */}
          <div className="relative md:col-span-3">
            <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 pointer-events-none">
              <Filter className="w-4 h-4" />
            </span>
            <select
              value={filterCondition}
              onChange={(e) => setFilterCondition(e.target.value)}
              className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500 text-sm text-slate-700 font-medium cursor-pointer transition-colors appearance-none"
            >
              <option value="all">All Conditions</option>
              <option value="balance">Outstanding Balance</option>
              <option value="allergies">With Medical Allergies</option>
              <option value="chronic">With Chronic Health Conditions</option>
            </select>
          </div>
        </div>
      </div>

      {/* Patient Table/List Grid */}
      <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
        {filteredPatients.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-xs font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-4 px-6">Patient ID</th>
                  <th className="py-4 px-6">Full Name</th>
                  <th className="py-4 px-6">Age / DOB</th>
                  <th className="py-4 px-6">Contact Details</th>
                  <th className="py-4 px-6">Medical Summary</th>
                  <th className="py-4 px-6 text-right">Pending Balance</th>
                  <th className="py-4 px-6 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredPatients.map(p => {
                  // Calculate age
                  const birthDate = new Date(p.dob);
                  const today = new Date();
                  let age = today.getFullYear() - birthDate.getFullYear();
                  const monthDiff = today.getMonth() - birthDate.getMonth();
                  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                  }

                  return (
                    <tr 
                      key={p.id}
                      className="hover:bg-slate-50/50 cursor-pointer transition-colors group"
                    >
                      {/* ID */}
                      <td className="py-4 px-6" onClick={() => onSelectPatient(p.id)}>
                        <span className="font-mono text-xs font-bold text-slate-400 group-hover:text-red-600 transition-colors">{p.id}</span>
                      </td>

                      {/* Name */}
                      <td className="py-4 px-6 font-bold text-slate-900" onClick={() => onSelectPatient(p.id)}>
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-red-50 border border-red-100 flex items-center justify-center text-red-700 font-bold text-xs shrink-0">
                            {p.name.charAt(0)}
                          </div>
                          <div>
                            <div className="group-hover:text-red-600 transition-colors">{p.name}</div>
                            <div className="text-[10px] text-slate-400 font-medium capitalize mt-0.5">{p.gender} • Blood: {p.bloodType}</div>
                          </div>
                        </div>
                      </td>

                      {/* DOB / Age */}
                      <td className="py-4 px-6 text-slate-600" onClick={() => onSelectPatient(p.id)}>
                        <div className="font-semibold">{age} years</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">{p.dob}</div>
                      </td>

                      {/* Contacts */}
                      <td className="py-4 px-6 text-slate-500 text-xs" onClick={() => onSelectPatient(p.id)}>
                        <div className="flex items-center gap-1"><Phone className="w-3 h-3 text-slate-400" /> {p.phone}</div>
                        <div className="flex items-center gap-1 mt-1 text-slate-400"><Mail className="w-3 h-3 text-slate-300" /> {p.email}</div>
                      </td>

                      {/* Medical warnings */}
                      <td className="py-4 px-6" onClick={() => onSelectPatient(p.id)}>
                        <div className="flex flex-wrap gap-1 max-w-[200px]">
                          {p.allergies.length > 0 && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-red-50 border border-red-100 text-red-600 flex items-center gap-0.5" title={`Allergies: ${p.allergies.join(', ')}`}>
                              <AlertTriangle className="w-3 h-3" /> Allergy
                            </span>
                          )}
                          {p.chronicConditions.length > 0 && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 border border-amber-100 text-amber-600" title={`Conditions: ${p.chronicConditions.join(', ')}`}>
                              Chronic
                            </span>
                          )}
                          {p.allergies.length === 0 && p.chronicConditions.length === 0 && (
                            <span className="text-[10px] font-medium text-slate-400">Clear Medical History</span>
                          )}
                        </div>
                      </td>

                      {/* Balance */}
                      <td className="py-4 px-6 text-right font-black" onClick={() => onSelectPatient(p.id)}>
                        <span className={p.balance > 0 ? 'text-red-600' : 'text-slate-400'}>
                          {p.balance > 0 ? `GH₵${p.balance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}` : '—'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-6 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => onSelectPatient(p.id)}
                            className="p-1.5 bg-slate-50 hover:bg-red-50 hover:text-red-600 text-slate-400 rounded-lg transition-colors cursor-pointer"
                            title="View electronic dental chart & files"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Are you sure you want to remove patient ${p.name}? This cannot be undone.`)) {
                                onDeletePatient(p.id);
                              }
                            }}
                            className="p-1.5 bg-slate-50 hover:bg-red-50 hover:text-red-500 text-slate-400 rounded-lg transition-colors"
                            title="Delete patient record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-16 px-6">
            <User className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="font-bold text-slate-800">No Patient Records Found</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">Try adjusting your filters, clearing your search query, or register a new patient file above.</p>
          </div>
        )}
      </div>

      {/* Add Patient Modal */}
      {showAddForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white border border-slate-100 rounded-2xl shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6 md:p-8 relative">
            <button
              onClick={() => setShowAddForm(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-xl font-bold p-1 hover:bg-slate-50 rounded-lg"
            >
              &times;
            </button>

            <h3 className="text-xl font-extrabold text-slate-900 border-b border-slate-100 pb-3 mb-6">Patient Clinical Registration</h3>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Core Details */}
              <div>
                <h4 className="text-xs font-bold text-red-600 uppercase tracking-widest border-l-2 border-red-500 pl-2 mb-4">1. Personal Demographics</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Kofi Mensah"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Date of Birth *</label>
                    <input
                      type="date"
                      required
                      value={newDob}
                      onChange={(e) => setNewDob(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Gender *</label>
                    <select
                      value={newGender}
                      onChange={(e) => setNewGender(e.target.value as any)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Phone Number</label>
                    <input
                      type="tel"
                      placeholder="e.g. +233 24 123 4567"
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Email Address</label>
                    <input
                      type="email"
                      placeholder="e.g. kofi.mensah@email.gh"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Blood Type</label>
                    <select
                      value={newBloodType}
                      onChange={(e) => setNewBloodType(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    >
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </div>

                  <div className="md:col-span-3">
                    <label className="text-xs font-bold text-slate-500 block mb-1">Residential Address</label>
                    <input
                      type="text"
                      placeholder="e.g. No. 45 Anumsa Street, East Legon, Accra"
                      value={newAddress}
                      onChange={(e) => setNewAddress(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>
              </div>

              {/* Medical Summary Details */}
              <div>
                <h4 className="text-xs font-bold text-red-600 uppercase tracking-widest border-l-2 border-red-500 pl-2 mb-4">2. Clinical Health Intake</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Allergies (comma separated)</label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Penicillin, Aspirin, Latex"
                      value={newAllergies}
                      onChange={(e) => setNewAllergies(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 resize-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Chronic Conditions / Illnesses (comma separated)</label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Diabetes, Asthma, Hypertension"
                      value={newConditions}
                      onChange={(e) => setNewConditions(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* Emergency Contact */}
              <div>
                <h4 className="text-xs font-bold text-red-600 uppercase tracking-widest border-l-2 border-red-500 pl-2 mb-4">3. Emergency Contact</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Contact Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Clara Mensah"
                      value={emergencyName}
                      onChange={(e) => setEmergencyName(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Relationship</label>
                    <input
                      type="text"
                      placeholder="e.g. Spouse / Parent / Sibling"
                      value={emergencyRelationship}
                      onChange={(e) => setEmergencyRelationship(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">Phone Number</label>
                    <input
                      type="tel"
                      placeholder="e.g. +233 24 123 4568"
                      value={emergencyPhone}
                      onChange={(e) => setEmergencyPhone(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-3 border-t border-slate-100 pt-5">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="py-2.5 px-4 border border-slate-200 hover:bg-slate-50 text-slate-500 font-bold text-xs rounded-xl transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
                >
                  Complete Registration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
