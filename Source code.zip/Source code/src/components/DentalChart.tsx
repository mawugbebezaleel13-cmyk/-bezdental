/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Odontogram, ToothCondition, ToothSurface, ToothState } from '../types';
import { UNIVERSAL_TEETH } from '../sampleData';
import { ShieldAlert, Trash2, CheckCircle2, Award, Hammer, RefreshCw, Layers, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DentalChartProps {
  odontogram: Odontogram;
  onChange: (updatedOdontogram: Odontogram) => void;
  readOnly?: boolean;
}

const CONDITION_COLORS: Record<ToothCondition, { bg: string; text: string; fill: string; border: string }> = {
  healthy: { bg: 'bg-white', text: 'text-slate-700', fill: '#f8fafc', border: 'stroke-slate-300' },
  caries: { bg: 'bg-red-500', text: 'text-white', fill: '#ef4444', border: 'stroke-red-600' },
  filled: { bg: 'bg-blue-500', text: 'text-white', fill: '#3b82f6', border: 'stroke-blue-600' },
  missing: { bg: 'bg-slate-200 line-through', text: 'text-slate-500', fill: '#e2e8f0', border: 'stroke-slate-400' },
  crown: { bg: 'bg-amber-500', text: 'text-white', fill: '#f59e0b', border: 'stroke-amber-600' },
  bridge: { bg: 'bg-purple-500', text: 'text-white', fill: '#a855f7', border: 'stroke-purple-600' },
  implant: { bg: 'bg-rose-600', text: 'text-white', fill: '#e11d48', border: 'stroke-rose-700' },
  root_canal: { bg: 'bg-emerald-500', text: 'text-white', fill: '#10b981', border: 'stroke-emerald-600' },
};

export default function DentalChart({ odontogram, onChange, readOnly = false }: DentalChartProps) {
  const [selectedToothNum, setSelectedToothNum] = useState<number | null>(null);
  const [activeCondition, setActiveCondition] = useState<ToothCondition>('caries');
  const [toothNotes, setToothNotes] = useState<string>('');

  const handleToothClick = (num: number) => {
    setSelectedToothNum(num);
    setToothNotes(odontogram[num]?.notes || '');
  };

  const handleApplyConditionToSurface = (num: number, surface: ToothSurface, condition: ToothCondition) => {
    if (readOnly) return;
    const currentTooth = odontogram[num] || {
      surfaces: { top: 'healthy', bottom: 'healthy', left: 'healthy', right: 'healthy', center: 'healthy', all: 'healthy' },
      notes: ''
    };

    let updatedSurfaces = { ...currentTooth.surfaces };

    if (surface === 'all') {
      // Apply to all surfaces
      updatedSurfaces = {
        top: condition,
        bottom: condition,
        left: condition,
        right: condition,
        center: condition,
        all: condition,
      };
    } else {
      updatedSurfaces[surface] = condition;
      // If any specific surface is modified, 'all' is no longer uniform unless all are healthy
      updatedSurfaces.all = 'healthy';
    }

    const updatedOdontogram = {
      ...odontogram,
      [num]: {
        ...currentTooth,
        surfaces: updatedSurfaces,
      },
    };

    onChange(updatedOdontogram);
  };

  const handleSaveNotes = () => {
    if (selectedToothNum === null || readOnly) return;
    const currentTooth = odontogram[selectedToothNum] || {
      surfaces: { top: 'healthy', bottom: 'healthy', left: 'healthy', right: 'healthy', center: 'healthy', all: 'healthy' },
      notes: ''
    };

    const updatedOdontogram = {
      ...odontogram,
      [selectedToothNum]: {
        ...currentTooth,
        notes: toothNotes,
      },
    };
    onChange(updatedOdontogram);
    setSelectedToothNum(null);
  };

  const handleResetTooth = (num: number) => {
    if (readOnly) return;
    const updatedOdontogram = {
      ...odontogram,
      [num]: {
        surfaces: {
          top: 'healthy' as ToothCondition,
          bottom: 'healthy' as ToothCondition,
          left: 'healthy' as ToothCondition,
          right: 'healthy' as ToothCondition,
          center: 'healthy' as ToothCondition,
          all: 'healthy' as ToothCondition,
        },
        notes: '',
      },
    };
    onChange(updatedOdontogram);
    setToothNotes('');
  };

  const renderToothSVG = (num: number, scale = 1) => {
    const toothState = odontogram[num] || {
      surfaces: { top: 'healthy', bottom: 'healthy', left: 'healthy', right: 'healthy', center: 'healthy', all: 'healthy' },
      notes: ''
    };

    const isMissing = toothState.surfaces.all === 'missing';
    const isCrown = toothState.surfaces.all === 'crown';
    const isImplant = toothState.surfaces.all === 'implant';
    const isBridge = toothState.surfaces.all === 'bridge';
    const isRootCanal = toothState.surfaces.all === 'root_canal';

    const s = scale;
    const width = 36 * s;
    const height = 36 * s;

    // Get color fills for each surface
    const getFill = (surf: ToothSurface) => {
      if (isMissing) return '#f1f5f9';
      if (isCrown) return CONDITION_COLORS.crown.fill;
      if (isImplant) return CONDITION_COLORS.implant.fill;
      if (isBridge) return CONDITION_COLORS.bridge.fill;
      if (isRootCanal && surf === 'center') return CONDITION_COLORS.root_canal.fill;

      const cond = toothState.surfaces[surf];
      return CONDITION_COLORS[cond]?.fill || '#f8fafc';
    };

    const handleSurfaceClick = (e: React.MouseEvent, surf: ToothSurface) => {
      if (readOnly) return;
      if (selectedToothNum === num) {
        e.stopPropagation();
        handleApplyConditionToSurface(num, surf, activeCondition);
      }
    };

    const getSurfaceClass = (surf: ToothSurface) => {
      const isSelected = selectedToothNum === num;
      const base = "stroke-slate-300 stroke-[1.5] transition-colors duration-150";
      if (isSelected && !readOnly) {
        return `${base} hover:stroke-red-500 hover:stroke-[2.5] hover:fill-red-500/10 cursor-crosshair`;
      }
      return base;
    };

    return (
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: (num % 16) * 0.015, type: 'spring', stiffness: 220, damping: 16 }}
        className="relative flex flex-col items-center"
      >
        <svg
          width={width}
          height={height}
          viewBox="0 0 36 36"
          className={`cursor-pointer transition-transform hover:scale-105 duration-200 ${
            selectedToothNum === num ? 'ring-2 ring-red-500 rounded-md ring-offset-2' : ''
          }`}
          onClick={() => handleToothClick(num)}
        >
          {/* Background Group */}
          <g>
            {/* Top Surface (Buccal/Labial) */}
            <polygon
              points="2,2 34,2 24,12 12,12"
              fill={getFill('top')}
              onClick={(e) => handleSurfaceClick(e, 'top')}
              className={getSurfaceClass('top')}
            />
            {/* Right Surface (Distal/Mesial based on quad) */}
            <polygon
              points="34,2 34,34 24,24 24,12"
              fill={getFill('right')}
              onClick={(e) => handleSurfaceClick(e, 'right')}
              className={getSurfaceClass('right')}
            />
            {/* Bottom Surface (Lingual) */}
            <polygon
              points="12,24 24,24 34,34 2,34"
              fill={getFill('bottom')}
              onClick={(e) => handleSurfaceClick(e, 'bottom')}
              className={getSurfaceClass('bottom')}
            />
            {/* Left Surface */}
            <polygon
              points="2,2 12,12 12,24 2,34"
              fill={getFill('left')}
              onClick={(e) => handleSurfaceClick(e, 'left')}
              className={getSurfaceClass('left')}
            />
            {/* Center Surface (Occlusal/Incisal) */}
            <rect
              x="12"
              y="12"
              width="12"
              height="12"
              fill={getFill('center')}
              onClick={(e) => handleSurfaceClick(e, 'center')}
              className={getSurfaceClass('center')}
            />
          </g>

          {/* Overlays for overall tooth statuses */}
          {isMissing && (
            <g className="pointer-events-none">
              <line x1="2" y1="2" x2="34" y2="34" stroke="#64748b" strokeWidth="2.5" strokeDasharray="2 1" />
              <line x1="34" y1="2" x2="2" y2="34" stroke="#64748b" strokeWidth="2.5" strokeDasharray="2 1" />
            </g>
          )}

          {isImplant && (
            <g className="pointer-events-none" transform="translate(11, 11)">
              {/* Draw a tiny bolt/implant screw icon in center */}
              <path d="M7 1v12M3 4h8M4 7h6M5 10h4" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
            </g>
          )}

          {isRootCanal && !isCrown && !isImplant && (
            <g className="pointer-events-none">
              {/* Draw vertical root lines */}
              <line x1="18" y1="4" x2="18" y2="32" stroke="#10b981" strokeWidth="3" strokeLinecap="round" />
            </g>
          )}
        </svg>

        {/* Tooth number display */}
        <span className="text-xs font-semibold text-slate-500 mt-1">{num}</span>
      </motion.div>
    );
  };

  // Group teeth into upper arch (1-16) and lower arch (17-32)
  const upperTeeth = UNIVERSAL_TEETH.filter(t => t.arch === 'Upper');
  const lowerTeeth = UNIVERSAL_TEETH.filter(t => t.arch === 'Lower').reverse(); // lower arch goes 32 to 17 left-to-right

  const selectedToothInfo = UNIVERSAL_TEETH.find(t => t.num === selectedToothNum);
  const selectedToothState = selectedToothNum !== null ? odontogram[selectedToothNum] : null;

  return (
    <div id="dental-records-chart" className="flex flex-col xl:flex-row gap-6 p-1">
      {/* Interactive Odontogram Grid */}
      <div className="flex-1 bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Interactive Odontogram</h3>
            <p className="text-sm text-slate-500">Universal Numbering System. Click a tooth to view details, notes, or modify surfaces.</p>
          </div>
          <div className="flex flex-wrap gap-2 text-xs">
            {Object.entries(CONDITION_COLORS).map(([cond, col]) => (
              <div key={cond} className="flex items-center gap-1.5 px-2 py-1 bg-slate-50 border border-slate-100 rounded-md">
                <span className={`w-3 h-3 rounded-sm ${col.bg} border border-slate-300 inline-block`}></span>
                <span className="capitalize font-medium text-slate-600">{cond.replace('_', ' ')}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-10 overflow-x-auto py-4">
          {/* Upper Arch */}
          <div>
            <div className="text-center font-bold text-xs text-slate-400 uppercase tracking-wider mb-3">Upper Arch (Maxilla)</div>
            <div className="flex justify-between items-center gap-2 min-w-[640px] px-2 bg-slate-50/50 py-4 rounded-xl border border-slate-100">
              <span className="text-xs font-bold text-slate-400 select-none w-10 text-center">R</span>
              <div className="flex justify-between flex-1">
                {upperTeeth.map(t => (
                  <div key={t.num} className="flex-1 flex justify-center">
                    {renderToothSVG(t.num)}
                  </div>
                ))}
              </div>
              <span className="text-xs font-bold text-slate-400 select-none w-10 text-center">L</span>
            </div>
          </div>

          {/* Lower Arch */}
          <div>
            <div className="flex justify-between items-center gap-2 min-w-[640px] px-2 bg-slate-50/50 py-4 rounded-xl border border-slate-100">
              <span className="text-xs font-bold text-slate-400 select-none w-10 text-center">R</span>
              <div className="flex justify-between flex-1">
                {/* Lower teeth list goes 32 on the right, to 17 on the left.
                    Wait, let's render them in sequence that matches clinical layout:
                    Universal #17 is Left Wisdom, #32 is Right Wisdom.
                    So looking at patient: right-side of chart is patient's right (teeth 1-8 and 25-32),
                    left-side of chart is patient's left (teeth 9-16 and 17-24).
                    So Upper is 1 to 16. Lower is 32 to 17 to line up Right-to-Right and Left-to-Left.
                */}
                {lowerTeeth.map(t => (
                  <div key={t.num} className="flex-1 flex justify-center">
                    {renderToothSVG(t.num)}
                  </div>
                ))}
              </div>
              <span className="text-xs font-bold text-slate-400 select-none w-10 text-center">L</span>
            </div>
            <div className="text-center font-bold text-xs text-slate-400 uppercase tracking-wider mt-3">Lower Arch (Mandible)</div>
          </div>
        </div>
      </div>

      {/* Tooth Inspector Panel */}
      <div className="w-full xl:w-96 min-h-[350px]">
        <AnimatePresence mode="wait">
          {selectedToothNum !== null && selectedToothInfo && selectedToothState ? (
            <motion.div
              key={`selected-${selectedToothNum}`}
              initial={{ opacity: 0, x: 15 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -15 }}
              transition={{ type: 'spring', stiffness: 350, damping: 26 }}
              className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-col h-full"
            >
              <div className="flex items-start justify-between border-b border-slate-800 pb-4 mb-4">
                <div>
                  <span className="text-xs font-bold tracking-widest text-red-400 uppercase">Tooth Details</span>
                  <h4 className="text-xl font-bold mt-0.5">Tooth #{selectedToothNum}</h4>
                  <p className="text-xs text-slate-400 mt-1 font-medium">{selectedToothInfo.name}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">{selectedToothInfo.arch} Arch • {selectedToothInfo.quad} Quadrant</p>
                </div>
                <button
                  onClick={() => setSelectedToothNum(null)}
                  className="text-slate-400 hover:text-white transition-colors text-sm font-semibold p-1.5 hover:bg-slate-800 rounded-lg"
                >
                  Close
                </button>
              </div>

              {/* Visual zoomed in tooth representation */}
              <div className="flex justify-center items-center py-6 bg-slate-950 rounded-xl mb-5 border border-slate-800 relative group">
                <div className="scale-125">
                  {renderToothSVG(selectedToothNum, 1.8)}
                </div>
                {!readOnly && (
                  <div className="absolute bottom-2 right-2 text-[10px] text-slate-500 pointer-events-none">
                    Interactive Preview
                  </div>
                )}
              </div>

              {/* Editing tools */}
              {!readOnly ? (
                <div className="space-y-4 flex-1">
                  {/* Condition Selector */}
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">1. Select Condition</label>
                    <div className="grid grid-cols-2 gap-2">
                      {(Object.keys(CONDITION_COLORS) as ToothCondition[]).map(cond => {
                        const col = CONDITION_COLORS[cond];
                        const isActive = activeCondition === cond;
                        return (
                          <button
                            key={cond}
                            onClick={() => setActiveCondition(cond)}
                            className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium border text-left transition-all ${
                              isActive
                                ? 'bg-slate-800 border-red-500 text-white shadow-sm shadow-red-500/10 font-bold'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <span className={`w-3 h-3 rounded-sm ${col.bg} border border-white/10 shrink-0`}></span>
                            <span className="capitalize">{cond.replace('_', ' ')}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Surface Apply Buttons */}
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">2. Apply to Surfaces</label>
                    <div className="space-y-2">
                      <button
                        onClick={() => handleApplyConditionToSurface(selectedToothNum, 'all', activeCondition)}
                        className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-red-600 hover:bg-red-500 text-white font-semibold text-xs rounded-lg shadow-sm transition-all cursor-pointer"
                      >
                        <Layers className="w-3.5 h-3.5" /> Apply to Full Tooth (All Surfaces)
                      </button>

                      <div className="grid grid-cols-5 gap-1 text-[10px] text-center">
                        {(['top', 'bottom', 'left', 'right', 'center'] as ToothSurface[]).map(surf => (
                          <button
                            key={surf}
                            onClick={() => handleApplyConditionToSurface(selectedToothNum, surf, activeCondition)}
                            className="py-1.5 px-1 bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 font-semibold rounded-md capitalize transition-all"
                          >
                            {surf === 'top' ? 'Buccal' : surf === 'bottom' ? 'Lingual' : surf === 'left' ? 'Mesial' : surf === 'right' ? 'Distal' : 'Occlusal'}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Notes Input */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                        <FileText className="w-3 h-3" /> 3. Clinical Notes
                      </label>
                      {toothNotes && (
                        <span className="text-[10px] text-red-400 font-medium">Drafting...</span>
                      )}
                    </div>
                    <textarea
                      rows={3}
                      value={toothNotes}
                      onChange={(e) => setToothNotes(e.target.value)}
                      placeholder="Enter tooth-specific diagnosis, treatments, or notes..."
                      className="w-full text-xs bg-slate-950 border border-slate-800 focus:border-red-500 rounded-lg p-2.5 text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-red-500 transition-all resize-none"
                    />
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => handleResetTooth(selectedToothNum)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 border border-slate-800 hover:bg-slate-850 hover:border-slate-700 text-slate-400 hover:text-white font-semibold text-xs rounded-lg transition-all"
                      title="Clear all markings on this tooth"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Reset
                    </button>
                    <button
                      onClick={handleSaveNotes}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-white text-slate-950 font-bold text-xs rounded-lg transition-all"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Save Changes
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 flex-1">
                  {/* Read Only Inspector Details */}
                  <div>
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Surface Statuses</div>
                    <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 text-xs space-y-1.5">
                      <div className="flex justify-between"><span className="text-slate-500">Buccal (Top)</span><span className="capitalize font-medium text-slate-300">{selectedToothState.surfaces.top}</span></div>
                      <div className="flex justify-between"><span className="text-slate-500">Lingual (Bottom)</span><span className="capitalize font-medium text-slate-300">{selectedToothState.surfaces.bottom}</span></div>
                      <div className="flex justify-between"><span className="text-slate-500">Mesial (Left)</span><span className="capitalize font-medium text-slate-300">{selectedToothState.surfaces.left}</span></div>
                      <div className="flex justify-between"><span className="text-slate-500">Distal (Right)</span><span className="capitalize font-medium text-slate-300">{selectedToothState.surfaces.right}</span></div>
                      <div className="flex justify-between"><span className="text-slate-500">Occlusal (Center)</span><span className="capitalize font-medium text-slate-300">{selectedToothState.surfaces.center}</span></div>
                    </div>
                  </div>

                  <div className="border-t border-slate-800 pt-3">
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Clinical Notes</div>
                    <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 text-xs italic text-slate-400 leading-relaxed min-h-[80px]">
                      {selectedToothState.notes || "No custom notes recorded for this tooth."}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="empty-inspector"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.2 }}
              className="h-full flex flex-col items-center justify-center text-center p-6 bg-slate-50 border border-dashed border-slate-200 rounded-2xl min-h-[350px]"
            >
              <ShieldAlert className="w-10 h-10 text-slate-300 mb-2" />
              <h4 className="font-bold text-slate-700">No Tooth Selected</h4>
              <p className="text-xs text-slate-400 max-w-[200px] mt-1">Click any tooth on the odontogram grid to inspect and modify clinical conditions.</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
