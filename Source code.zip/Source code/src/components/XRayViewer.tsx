/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { XRayFile, XRayAnnotation } from '../types';
import { 
  Maximize2, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Image, 
  FileText, 
  Sliders, 
  MapPin, 
  Check, 
  HelpCircle 
} from 'lucide-react';

interface XRayViewerProps {
  xrays: XRayFile[];
  onAddXray: (newXray: XRayFile) => void;
  onUpdateXrayAnnotations: (xrayId: string, annotations: XRayAnnotation[]) => void;
  readOnly?: boolean;
}

export default function XRayViewer({ 
  xrays, 
  onAddXray, 
  onUpdateXrayAnnotations,
  readOnly = false 
}: XRayViewerProps) {
  const [selectedXrayId, setSelectedXrayId] = useState<string | null>(
    xrays.length > 0 ? xrays[0].id : null
  );

  // Filters State
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [invert, setInvert] = useState<boolean>(false);
  const [grayscale, setGrayscale] = useState<boolean>(true);

  // Zoom & Pan States
  const [zoom, setZoom] = useState<number>(100);
  const [panX, setPanX] = useState<number>(0);
  const [panY, setPanY] = useState<number>(0);

  // Presets helper
  const applyPreset = (preset: 'default' | 'dentin' | 'bone' | 'soft') => {
    switch (preset) {
      case 'default':
        setBrightness(100);
        setContrast(100);
        setInvert(false);
        setGrayscale(true);
        setZoom(100);
        setPanX(0);
        setPanY(0);
        break;
      case 'dentin':
        setBrightness(110);
        setContrast(165);
        setInvert(false);
        setGrayscale(true);
        setZoom(130);
        break;
      case 'bone':
        setBrightness(85);
        setContrast(185);
        setInvert(true);
        setGrayscale(true);
        setZoom(150);
        break;
      case 'soft':
        setBrightness(125);
        setContrast(115);
        setInvert(false);
        setGrayscale(false);
        setZoom(110);
        break;
    }
  };

  // Annotation Mode State
  const [isAnnotating, setIsAnnotating] = useState<boolean>(false);
  const [selectedAnnotationId, setSelectedAnnotationId] = useState<string | null>(null);
  
  // Annotation Form
  const [newAnnotationLabel, setNewAnnotationLabel] = useState<string>('');
  const [newAnnotationDetails, setNewAnnotationDetails] = useState<string>('');

  const imageContainerRef = useRef<HTMLDivElement>(null);

  const selectedXray = xrays.find(x => x.id === selectedXrayId);

  // Handle Image Click (for annotation placement)
  const handleImageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isAnnotating || !selectedXray || !imageContainerRef.current || readOnly) return;

    const rect = imageContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    const newAnn: XRayAnnotation = {
      id: `ANN-${Date.now()}`,
      x: parseFloat(x.toFixed(1)),
      y: parseFloat(y.toFixed(1)),
      label: 'New Annotation Pin',
      details: 'Double click or select from list to rename and add clinical diagnostic details.'
    };

    const updatedAnnotations = [...selectedXray.annotations, newAnn];
    onUpdateXrayAnnotations(selectedXray.id, updatedAnnotations);
    setSelectedAnnotationId(newAnn.id);
    setNewAnnotationLabel(newAnn.label);
    setNewAnnotationDetails(newAnn.details || '');
    setIsAnnotating(false); // turn off annotation mode after placing pin
  };

  const handleUpdateAnnotation = () => {
    if (!selectedXray || !selectedAnnotationId || readOnly) return;

    const updated = selectedXray.annotations.map(ann => {
      if (ann.id === selectedAnnotationId) {
        return {
          ...ann,
          label: newAnnotationLabel || 'Annotation Pin',
          details: newAnnotationDetails
        };
      }
      return ann;
    });

    onUpdateXrayAnnotations(selectedXray.id, updated);
    setSelectedAnnotationId(null);
  };

  const handleDeleteAnnotation = (annId: string) => {
    if (!selectedXray || readOnly) return;
    const updated = selectedXray.annotations.filter(ann => ann.id !== annId);
    onUpdateXrayAnnotations(selectedXray.id, updated);
    if (selectedAnnotationId === annId) {
      setSelectedAnnotationId(null);
    }
  };

  const resetFilters = () => {
    setBrightness(100);
    setContrast(100);
    setInvert(false);
    setGrayscale(true);
    setZoom(100);
    setPanX(0);
    setPanY(0);
  };

  // Add dummy diagnostic scan helper
  const handleAddDummyScan = () => {
    if (readOnly) return;
    const dummyScan: XRayFile = {
      id: `XR-0${xrays.length + 10}`,
      name: "Bite-wing X-Ray Posterior (Simulated)",
      date: new Date().toISOString().split('T')[0],
      imageUrl: "https://images.unsplash.com/photo-1559757175-5700dde675bc?q=80&w=800&auto=format&fit=crop",
      notes: "Newly imported intraoral bite-wing radiograph. General crown margins adequate.",
      annotations: []
    };
    onAddXray(dummyScan);
    setSelectedXrayId(dummyScan.id);
  };

  return (
    <div id="imaging-station" className="space-y-6">
      {/* Upper selector & instructions */}
      <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900">Digital Radiograph & Imaging Station</h3>
          <p className="text-xs text-slate-500">View diagnostic scans, apply digital filters to isolate bone densities, and map pathology annotations directly on images.</p>
        </div>
        <div className="flex gap-2">
          {!readOnly && (
            <button
              onClick={handleAddDummyScan}
              className="flex items-center gap-1.5 py-2 px-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Import Diagnostic Scan
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Scans Sidebar */}
        <div className="xl:col-span-3 space-y-4">
          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Patient Scans List</h4>
            {xrays.length > 0 ? (
              <div className="space-y-2">
                {xrays.map(xr => (
                  <button
                    key={xr.id}
                    onClick={() => {
                      setSelectedXrayId(xr.id);
                      setSelectedAnnotationId(null);
                    }}
                    className={`w-full flex items-start gap-3 p-3 text-left rounded-xl border transition-all ${
                      selectedXrayId === xr.id
                        ? 'bg-slate-900 border-slate-800 text-white shadow-sm'
                        : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100/50'
                    }`}
                  >
                    <Image className={`w-4 h-4 shrink-0 mt-0.5 ${selectedXrayId === xr.id ? 'text-red-400' : 'text-slate-400'}`} />
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate">{xr.name}</div>
                      <div className={`text-[10px] mt-1 font-semibold ${selectedXrayId === xr.id ? 'text-slate-400' : 'text-slate-500'}`}>
                        {xr.date} • {xr.annotations.length} pins
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl">
                No clinical radiographs recorded for this patient file.
              </div>
            )}
          </div>
        </div>

        {/* Imaging Viewer Canvas */}
        <div className="xl:col-span-6 flex flex-col">
          {selectedXray ? (
            <div className="bg-slate-950 rounded-3xl overflow-hidden shadow-md flex flex-col">
              {/* Toolbar */}
              <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between text-white text-xs">
                <span className="font-semibold text-slate-300 truncate">{selectedXray.name} ({selectedXray.date})</span>
                <div className="flex items-center gap-1">
                  {!readOnly && (
                    <button
                      onClick={() => setIsAnnotating(!isAnnotating)}
                      className={`px-3 py-1 rounded-lg font-bold transition-all ${
                        isAnnotating 
                          ? 'bg-red-500 text-white animate-pulse'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                      }`}
                    >
                      {isAnnotating ? 'Click on X-ray to place...' : 'Place Pin Marker'}
                    </button>
                  )}
                  <button
                    onClick={resetFilters}
                    className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors"
                    title="Reset All Image Filters"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Canvas Area */}
              <div 
                ref={imageContainerRef}
                onClick={handleImageClick}
                className={`relative w-full overflow-hidden bg-black flex items-center justify-center min-h-[380px] max-h-[500px] select-none ${
                  isAnnotating ? 'cursor-crosshair' : 'cursor-default'
                }`}
              >
                {/* Outer wrapper that handles overflow, and inner wrapper that zooms/pans */}
                <div
                  style={{
                    transform: `scale(${zoom / 100}) translate(${panX}px, ${panY}px)`,
                    transformOrigin: 'center center',
                  }}
                  className="w-full h-full relative transition-all duration-200 ease-out flex items-center justify-center"
                >
                  {/* Radiograph Image with CSS filters */}
                  <img
                    src={selectedXray.imageUrl}
                    alt={selectedXray.name}
                    referrerPolicy="no-referrer"
                    style={{
                      filter: `brightness(${brightness}%) contrast(${contrast}%) ${invert ? 'invert(100%)' : 'invert(0%)'} ${grayscale ? 'grayscale(100%)' : 'grayscale(0%)'}`
                    }}
                    className="w-full h-auto max-h-[440px] object-contain pointer-events-none transition-all duration-150"
                  />

                  {/* Annotation Pins */}
                  {selectedXray.annotations.map(ann => (
                    <button
                      key={ann.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedAnnotationId(ann.id);
                        setNewAnnotationLabel(ann.label);
                        setNewAnnotationDetails(ann.details || '');
                      }}
                      className={`absolute w-6 h-6 rounded-full flex items-center justify-center shadow-lg border-2 transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-150 hover:scale-125 ${
                        selectedAnnotationId === ann.id
                          ? 'bg-red-500 border-white text-white z-20 scale-110 ring-4 ring-red-500/30'
                          : 'bg-white border-red-500 text-red-600 z-10'
                      }`}
                      style={{ left: `${ann.x}%`, top: `${ann.y}%` }}
                      title={ann.label}
                    >
                      <MapPin className="w-3.5 h-3.5" />
                    </button>
                  ))}
                </div>

                {/* Floating On-Canvas Mini-Controls */}
                <div className="absolute bottom-4 right-4 bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-2xl flex items-center gap-3 border border-slate-800/80 z-30 shadow-xl text-white">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setZoom(Math.max(100, zoom - 20))}
                      className="w-7 h-7 flex items-center justify-center bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold font-mono transition-colors"
                      title="Zoom Out"
                    >
                      -
                    </button>
                    <span className="text-[10px] font-mono font-bold w-10 text-center">{zoom}%</span>
                    <button
                      onClick={() => setZoom(Math.min(300, zoom + 20))}
                      className="w-7 h-7 flex items-center justify-center bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold font-mono transition-colors"
                      title="Zoom In"
                    >
                      +
                    </button>
                  </div>
                  <div className="h-4 w-px bg-slate-800" />
                  <button
                    onClick={() => {
                      setPanX(0);
                      setPanY(0);
                    }}
                    className="text-[9px] uppercase font-bold text-slate-400 hover:text-white px-1.5 transition-colors"
                  >
                    Center Pan
                  </button>
                </div>
              </div>

              {/* Clinical Diagnostic Presets Bar */}
              <div className="bg-slate-950 border-t border-slate-900 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-white text-xs select-none">
                <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">Diagnostic Presets</span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() => applyPreset('default')}
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 rounded-lg text-[10px] font-bold transition-all text-slate-300 border border-slate-800"
                  >
                    Default
                  </button>
                  <button
                    onClick={() => applyPreset('dentin')}
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 rounded-lg text-[10px] font-bold transition-all text-red-400 border border-red-900/40"
                  >
                    Caries/Dentin Focus
                  </button>
                  <button
                    onClick={() => applyPreset('bone')}
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 rounded-lg text-[10px] font-bold transition-all text-amber-400 border border-amber-900/40"
                  >
                    Bone Resorption View (Inverted)
                  </button>
                  <button
                    onClick={() => applyPreset('soft')}
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 rounded-lg text-[10px] font-bold transition-all text-purple-400 border border-purple-900/40"
                  >
                    Enamel Contrast
                  </button>
                </div>
              </div>

              {/* Image Controls Panel (Bottom Toolbar) */}
              <div className="bg-slate-900 border-t border-slate-800 p-4 grid grid-cols-1 md:grid-cols-3 gap-6 text-white text-xs select-none">
                {/* Sliders Column 1 */}
                <div className="space-y-3">
                  {/* Brightness */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-400 font-bold text-[10px] uppercase">
                      <span>Brightness</span>
                      <span>{brightness}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="200"
                      value={brightness}
                      onChange={(e) => setBrightness(parseInt(e.target.value))}
                      className="w-full accent-red-500 bg-slate-950 h-1 rounded-full cursor-pointer"
                    />
                  </div>

                  {/* Contrast */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-400 font-bold text-[10px] uppercase">
                      <span>Contrast</span>
                      <span>{contrast}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="250"
                      value={contrast}
                      onChange={(e) => setContrast(parseInt(e.target.value))}
                      className="w-full accent-red-500 bg-slate-950 h-1 rounded-full cursor-pointer"
                    />
                  </div>
                </div>

                {/* Sliders Column 2 (Fine Zoom & Fine Pan Offset) */}
                <div className="space-y-3">
                  {/* Fine Zoom */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-400 font-bold text-[10px] uppercase">
                      <span>Fine Zoom</span>
                      <span>{zoom}%</span>
                    </div>
                    <input
                      type="range"
                      min="100"
                      max="300"
                      value={zoom}
                      onChange={(e) => setZoom(parseInt(e.target.value))}
                      className="w-full accent-red-500 bg-slate-950 h-1 rounded-full cursor-pointer"
                    />
                  </div>

                  {/* Fine Pan Offsets */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-400 font-bold text-[10px] uppercase">
                      <span>Fine Pan (X, Y)</span>
                      <span className="font-mono text-[9px] text-red-400">{panX}px, {panY}px</span>
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="range"
                        min="-150"
                        max="150"
                        value={panX}
                        onChange={(e) => setPanX(parseInt(e.target.value))}
                        className="w-1/2 accent-red-500 bg-slate-950 h-1 rounded-full cursor-pointer"
                        title="Horizontal Pan"
                      />
                      <input
                        type="range"
                        min="-150"
                        max="150"
                        value={panY}
                        onChange={(e) => setPanY(parseInt(e.target.value))}
                        className="w-1/2 accent-red-500 bg-slate-950 h-1 rounded-full cursor-pointer"
                        title="Vertical Pan"
                      />
                    </div>
                  </div>
                </div>

                {/* Switches Column 3 */}
                <div className="flex flex-col justify-center gap-3">
                  {/* Invert */}
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-bold text-[10px] uppercase">Invert Colors</span>
                    <button
                      onClick={() => setInvert(!invert)}
                      className={`px-3 py-1 rounded-lg text-[10px] font-bold border transition-colors ${
                        invert
                          ? 'bg-red-600 text-white border-red-700'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {invert ? 'ON' : 'OFF'}
                    </button>
                  </div>

                  {/* Grayscale */}
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-bold text-[10px] uppercase">Grayscale</span>
                    <button
                      onClick={() => setGrayscale(!grayscale)}
                      className={`px-3 py-1 rounded-lg text-[10px] font-bold border transition-colors ${
                        grayscale
                          ? 'bg-red-600 text-white border-red-700'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {grayscale ? 'X-Ray Gray' : 'True Color'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 min-h-[400px] flex flex-col items-center justify-center text-center p-8 bg-slate-50 border border-dashed border-slate-200 rounded-3xl">
              <Sliders className="w-12 h-12 text-slate-300 mb-3 animate-pulse" />
              <h4 className="font-bold text-slate-700">No Diagnostic Scan Selected</h4>
              <p className="text-xs text-slate-400 max-w-sm mt-1">Please select an existing dental X-ray scan from the left sidebar or import a new panoramic bite-wing file.</p>
            </div>
          )}
        </div>

        {/* Pin Annotation Metadata Inspector */}
        <div className="xl:col-span-3 space-y-4">
          {selectedXray && (
            <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm h-full flex flex-col justify-between min-h-[400px]">
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Annotation Map</h4>
                
                {selectedAnnotationId ? (
                  /* Annotation Editing Form */
                  <div className="space-y-4 animate-fade-in">
                    <div className="bg-red-50 border border-red-100 p-3 rounded-xl text-red-800 text-xs font-semibold flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-red-600 shrink-0" />
                      <span>Modifying Active Marker Pin</span>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-500 block mb-1">Marker Heading / Area *</label>
                      <input
                        type="text"
                        value={newAnnotationLabel}
                        onChange={(e) => setNewAnnotationLabel(e.target.value)}
                        placeholder="e.g. Caries on Tooth #14"
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 text-slate-700 font-medium"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-500 block mb-1">Clinical Observations</label>
                      <textarea
                        rows={5}
                        value={newAnnotationDetails}
                        onChange={(e) => setNewAnnotationDetails(e.target.value)}
                        placeholder="Detail decay depth, bone resorption, margins seal, root integrity..."
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-red-500 text-slate-600 leading-relaxed resize-none"
                      />
                    </div>

                    {!readOnly ? (
                      <div className="flex gap-2 pt-2 border-t border-slate-100">
                        <button
                          onClick={() => handleDeleteAnnotation(selectedAnnotationId)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 border border-red-200 text-red-500 hover:bg-red-50 font-bold text-xs rounded-lg transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Remove Pin
                        </button>
                        <button
                          onClick={handleUpdateAnnotation}
                          className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-lg transition-all"
                        >
                          <Check className="w-3.5 h-3.5" /> Save
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setSelectedAnnotationId(null)}
                        className="w-full py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition-all"
                      >
                        Back to List
                      </button>
                    )}
                  </div>
                ) : (
                  /* List of Annotations for active scan */
                  <div className="space-y-2">
                    {selectedXray.annotations.length > 0 ? (
                      selectedXray.annotations.map(ann => (
                        <div
                          key={ann.id}
                          onClick={() => {
                            setSelectedAnnotationId(ann.id);
                            setNewAnnotationLabel(ann.label);
                            setNewAnnotationDetails(ann.details || '');
                          }}
                          className="p-3 border border-slate-100 rounded-xl hover:border-red-500/30 hover:bg-red-50/10 cursor-pointer transition-all group flex items-start justify-between"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-slate-800 group-hover:text-red-600 transition-colors flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-red-500 inline-block"></span>
                              {ann.label}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate mt-1 leading-relaxed">
                              {ann.details || 'No detail comments logged.'}
                            </div>
                          </div>
                          {!readOnly && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteAnnotation(ann.id);
                              }}
                              className="text-slate-300 hover:text-red-500 transition-colors p-1"
                              title="Delete Pin"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-12 text-xs text-slate-400 border border-dashed border-slate-100 rounded-xl">
                        No annotation points mapped. Click "Place Pin Marker" above to start plotting.
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Small helper tips */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 text-[10px] text-slate-500 leading-relaxed mt-4 flex gap-2">
                <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <span>
                  Adjusting **Brightness** and **Contrast** aids in highlighting enamel fractures. Use **Invert** to review deep bone loss surrounding roots.
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
