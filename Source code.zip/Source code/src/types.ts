/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ToothCondition = 'healthy' | 'caries' | 'filled' | 'missing' | 'crown' | 'bridge' | 'implant' | 'root_canal';

export type ToothSurface = 'top' | 'bottom' | 'left' | 'right' | 'center' | 'all';

export interface ToothState {
  surfaces: Record<ToothSurface, ToothCondition>;
  notes?: string;
}

export type Odontogram = Record<number, ToothState>;

export interface TreatmentItem {
  id: string;
  code: string;
  name: string;
  category: 'Diagnostic' | 'Preventive' | 'Restorative' | 'Endodontic' | 'Periodontal' | 'Prosthodontic' | 'Oral Surgery' | 'Orthodontic';
  cost: number;
  notes?: string;
  status: 'planned' | 'in_progress' | 'completed';
  date: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  dentistName: string;
  dateTime: string; // ISO format
  duration: number; // in minutes
  reason: string;
  notes?: string;
  status: 'scheduled' | 'completed' | 'cancelled' | 'no_show';
}

export interface XRayAnnotation {
  id: string;
  x: number; // percentage width
  y: number; // percentage height
  label: string;
  details?: string;
}

export interface XRayFile {
  id: string;
  name: string;
  date: string;
  imageUrl: string;
  notes?: string;
  annotations: XRayAnnotation[];
}

export interface InvoiceItem {
  name: string;
  cost: number;
}

export interface Invoice {
  id: string;
  patientId: string;
  date: string;
  items: InvoiceItem[];
  discount: number; // percentage or fixed amount
  tax: number; // percentage
  total: number;
  insurancePaid: number;
  amountPaid: number;
  status: 'paid' | 'partial' | 'unpaid';
}

export interface Patient {
  id: string;
  name: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Other';
  phone: string;
  email: string;
  address: string;
  bloodType: string;
  allergies: string[];
  chronicConditions: string[];
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  odontogram: Odontogram;
  treatments: TreatmentItem[];
  xrays: XRayFile[];
  invoices: Invoice[];
  balance: number;
}

export interface ClinicStats {
  totalPatients: number;
  activeTreatments: number;
  appointmentsToday: number;
  pendingBilling: number;
  monthlyRevenue: number;
  patientGrowth: { month: string; count: number }[];
  treatmentDist: { category: string; count: number; value: number }[];
  conditionDist: Record<ToothCondition, number>;
}
